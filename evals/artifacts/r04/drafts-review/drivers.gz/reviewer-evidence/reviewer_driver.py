from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import traceback

from PySide6.QtCore import Qt, QTimer, QPoint
from PySide6.QtGui import QGuiApplication
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QMessageBox, QPushButton

ROOT = Path('/opt/ui-skill-lab-20261020/review-r04-drafts')
OUT = ROOT / 'reviewer-evidence'
DATA = OUT / 'own-data'
OUT.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('frozen_review_app', ROOT / 'app.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
app = QApplication([])
app.setStyle('Fusion')
app.setApplicationName('拍摄备注')
app.setOrganizationName('LocalStudio')
checks = []


def wait():
    app.processEvents()
    QTest.qWait(160)


def check(label, condition, detail=''):
    checks.append({'check': label, 'ok': bool(condition), 'detail': detail})
    if not condition:
        raise AssertionError(label + ': ' + detail)


def shot(window, name):
    wait()
    QGuiApplication.primaryScreen().grabWindow(window.winId()).save(str(OUT / (name + '.png')))


def paste(widget, text):
    widget.setFocus()
    app.clipboard().setText(text)
    QTest.keyClick(widget, Qt.Key.Key_A, Qt.KeyboardModifier.ControlModifier)
    QTest.keyClick(widget, Qt.Key.Key_V, Qt.KeyboardModifier.ControlModifier)
    wait()


def disk():
    return json.loads((DATA / 'projects.json').read_text())


def handle_dialog(name, action, record):
    dialog = QApplication.activeModalWidget()
    record['modal'] = isinstance(dialog, QMessageBox)
    if not isinstance(dialog, QMessageBox):
        return
    record['default'] = dialog.defaultButton().text()
    shot(dialog, name)
    if action == 'escape':
        QTest.keyClick(dialog, Qt.Key.Key_Escape)
    else:
        button = dialog.findChild(QPushButton, action)
        record['action_found'] = button is not None
        if button:
            QTest.mouseClick(button, Qt.MouseButton.LeftButton)


try:
    check('frozen source hash', hashlib.sha256((ROOT / 'app.py').read_bytes()).hexdigest() ==
          'a4d8481d45d94c60ed960605cd9a0be6eb88338e15081c2aef0c772f77dfac57')
    check('private fresh data directory', not DATA.exists())
    window = module.NotesWindow(DATA)
    window.show()
    window.activateWindow()
    wait()
    check('fresh list has exactly three local examples', window.project_list.count() == 3 and len(disk()['projects']) == 3)
    check('initial keyboard focus is project list', QApplication.focusWidget() is window.project_list)
    shot(window, '01-own-list')
    QTest.keyClick(window.project_list, Qt.Key.Key_Down)
    QTest.keyClick(window.project_list, Qt.Key.Key_Return)
    wait()
    check('keyboard Down + Enter opens second example', window.title_edit.text() == '陶器上新 · 白底静物')
    check('editor opens with title focus', QApplication.focusWidget() is window.title_edit)
    title = '陶器上新 · 周三补拍'
    notes = '评审独立备注：补拍杯口釉面。\n先用柔光，再拍一张硬光对照。\n保留壶嘴侧面的高光。'
    paste(window.title_edit, title)
    QTest.keyClick(window.title_edit, Qt.Key.Key_Tab)
    check('Tab from title reaches notes', QApplication.focusWidget() is window.notes_edit)
    paste(window.notes_edit, notes)
    check('editing marks draft dirty', window.is_dirty() and '有未保存' in window.state_label.text())
    QTest.keyClick(window.notes_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
    wait()
    saved = disk()['projects'][1]
    check('Ctrl+S writes exact title and multiline notes to actual file', saved['title'] == title and saved['notes'] == notes)
    check('saved state updates without losing note focus', not window.is_dirty() and '已保存到本机' in window.state_label.text() and QApplication.focusWidget() is window.notes_edit)
    shot(window, '02-own-saved')
    QTest.keyClick(window.notes_edit, Qt.Key.Key_Escape)
    wait()
    check('Escape returns saved draft to list with focus and selection', window.stack.currentWidget() is window.list_page and QApplication.focusWidget() is window.project_list and window.project_list.currentRow() == 1)
    check('list reflects saved title', window.project_list.currentItem().text().startswith(title))
    QTest.keyClick(window.project_list, Qt.Key.Key_Return)
    wait()
    check('reopen keeps both saved values', window.title_edit.text() == title and window.notes_edit.toPlainText() == notes)
    window.close()
    wait()
    window = module.NotesWindow(DATA)
    window.show()
    window.activateWindow()
    wait()
    QTest.keyClick(window.project_list, Qt.Key.Key_Down)
    QTest.keyClick(window.project_list, Qt.Key.Key_Return)
    wait()
    check('new window reloads title and notes from disk', window.title_edit.text() == title and window.notes_edit.toPlainText() == notes)
    window.resize(640, 480)
    wait()
    long_title = title + '（补拍灯光、人物站位以及窗边的备用构图）'
    long_notes = '\n'.join(f'机位 {i:02d}：核对杯口和壶嘴的光线。' for i in range(1, 71))
    paste(window.title_edit, long_title)
    paste(window.notes_edit, long_notes)
    QTest.keyClick(window.notes_edit, Qt.Key.Key_End, Qt.KeyboardModifier.ControlModifier)
    wait()
    check('640×480 editor retains requested window size', window.width() == 640 and window.height() == 480)
    check('long note supports keyboard navigation and scrolling', window.notes_edit.textCursor().atEnd() and window.notes_edit.verticalScrollBar().value() > 0)
    shot(window, '03-own-narrow-long-editor')
    dialog_record = {}
    QTimer.singleShot(100, lambda: handle_dialog('04-own-unsaved-dialog', 'escape', dialog_record))
    QTest.keyClick(window.notes_edit, Qt.Key.Key_Escape)
    wait()
    check('Escape on unsaved dialog keeps editor and note focus', dialog_record.get('modal') and dialog_record.get('default') == '继续编辑' and window.stack.currentWidget() is window.editor_page and QApplication.focusWidget() is window.notes_edit)
    QTest.keyClick(window.notes_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
    wait()
    check('narrow editor saves long content exactly', disk()['projects'][1]['title'] == long_title and disk()['projects'][1]['notes'] == long_notes)
    QTest.keyClick(window.notes_edit, Qt.Key.Key_Left, Qt.KeyboardModifier.AltModifier)
    wait()
    QTest.keyClick(window.project_list, Qt.Key.Key_Down)
    QTest.keyClick(window.project_list, Qt.Key.Key_Return)
    wait()
    check('narrow list third project is keyboard reachable', window.title_edit.text() == '周末家庭照 · 工作室')
    QTest.keyClick(window.title_edit, Qt.Key.Key_Escape)
    wait()
    shot(window, '05-own-narrow-third-list')
    QTest.keyClick(window.project_list, Qt.Key.Key_Up)
    QTest.keyClick(window.project_list, Qt.Key.Key_Return)
    wait()
    before_failure = (DATA / 'projects.json').read_bytes()
    paste(window.notes_edit, long_notes + '\n这行在真实写入失败后应留在编辑器。')
    (DATA / 'projects.json').rename(DATA / 'projects.saved.json')
    (DATA / 'projects.json').mkdir()
    QTest.keyClick(window.notes_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
    wait()
    check('real EISDIR failure keeps dirty editor and honest status', window.is_dirty() and window.error_frame.isVisible() and '保存失败' in window.state_label.text() and window.notes_edit.toPlainText().endswith('这行在真实写入失败后应留在编辑器。'))
    checks.append({'check': 'narrow failure geometry', 'ok': True, 'detail': {'window': [window.width(), window.height()], 'notes': [window.notes_edit.width(), window.notes_edit.height()], 'error_text': window.error_label.text(), 'error_tooltip': window.error_label.toolTip()}})
    shot(window, '06-own-narrow-write-failure')
    failure_record = {}
    QTimer.singleShot(100, lambda: handle_dialog('07-own-failure-return-dialog', 'saveAndLeave', failure_record))
    QTest.keyClick(window.notes_edit, Qt.Key.Key_Escape)
    wait()
    check('save-and-return cannot leave after failed write', failure_record.get('modal') and failure_record.get('action_found') and window.stack.currentWidget() is window.editor_page and window.is_dirty())
    check('failed replacement preserves previous file bytes', (DATA / 'projects.saved.json').read_bytes() == before_failure)
    (DATA / 'projects.json').rmdir()
    (DATA / 'projects.saved.json').rename(DATA / 'projects.json')
    QTest.mouseClick(window.retry_button, Qt.MouseButton.LeftButton)
    wait()
    check('retry after restoring path saves exact retained text', not window.is_dirty() and disk()['projects'][1]['notes'].endswith('这行在真实写入失败后应留在编辑器。'))
    window.resize(1180, 780)
    shot(window, '08-own-recovered')
    window.close()
    wait()
    bad_data = OUT / 'own-invalid-data'
    bad_data.mkdir()
    (bad_data / 'projects.json').write_text('{bad', encoding='utf-8')
    original_bytes = (bad_data / 'projects.json').read_bytes()
    window = module.NotesWindow(bad_data)
    window.show()
    window.activateWindow()
    wait()
    check('invalid file opens error page and preserves original', window.stack.currentWidget() is window.load_error_page and (bad_data / 'projects.json').read_bytes() == original_bytes)
    checks.append({'check': 'load failure recovery information', 'ok': True, 'detail': {'visible_text': window.load_error_label.text(), 'tooltip': window.load_error_label.toolTip(), 'page_texts': [v.text() for v in window.load_error_page.findChildren(module.QLabel)]}})
    shot(window, '09-own-load-error')
    window.close()
    wait()
except BaseException:
    checks.append({'exception': traceback.format_exc()})
finally:
    (OUT / 'reviewer-results.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(checks, ensure_ascii=False, indent=2))
    for widget in QApplication.topLevelWidgets():
        widget.hide()
    app.quit()
