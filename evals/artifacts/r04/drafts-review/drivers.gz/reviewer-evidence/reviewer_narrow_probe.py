import importlib.util
import json
from pathlib import Path
import shutil
from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

root = Path('/opt/ui-skill-lab-20261020/review-r04-drafts')
out = root / 'reviewer-evidence'
data = out / 'own-narrow-probe-data'
data.mkdir()
shutil.copyfile(out / 'own-data/projects.json', data / 'projects.json')
spec = importlib.util.spec_from_file_location('frozen_probe', root / 'app.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
app = QApplication([])
app.setStyle('Fusion')
w = mod.NotesWindow(data)
w.resize(640,480)
w.show()
w.activateWindow()
QTest.qWait(200)
QTest.keyClick(w.project_list, Qt.Key.Key_Down)
QTest.keyClick(w.project_list, Qt.Key.Key_Return)
QTest.qWait(100)
w.notes_edit.setFocus()
QTest.keyClick(w.notes_edit, Qt.Key.Key_End, Qt.KeyboardModifier.ControlModifier)
QTest.keyClick(w.notes_edit, Qt.Key.Key_Return)
QTest.keyClicks(w.notes_edit, 'END_REVIEW')
(data / 'projects.json').rename(data / 'projects.saved.json')
(data / 'projects.json').mkdir()
QTest.keyClick(w.notes_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
QTest.qWait(200)

def capture(name):
    rect = w.notes_edit.cursorRect()
    view = w.notes_edit.viewport().rect()
    info = {'name':name, 'cursor':[rect.x(),rect.y(),rect.width(),rect.height()], 'viewport':[view.x(),view.y(),view.width(),view.height()], 'cursor_fully_visible':view.contains(rect), 'cursor_intersects_viewport':view.intersects(rect), 'scroll_value':w.notes_edit.verticalScrollBar().value(), 'scroll_max':w.notes_edit.verticalScrollBar().maximum(), 'notes_height':w.notes_edit.height(), 'window':[w.width(),w.height()], 'at_end':w.notes_edit.textCursor().atEnd()}
    QGuiApplication.primaryScreen().grabWindow(w.winId()).save(str(out / (name+'.png')))
    return info

results=[capture('10-own-cursor-after-failure')]
QTest.keyClick(w.notes_edit, Qt.Key.Key_End, Qt.KeyboardModifier.ControlModifier)
QTest.qWait(200)
results.append(capture('11-own-cursor-after-ctrl-end'))
QTest.keyClicks(w.notes_edit, 'X')
QTest.qWait(200)
results.append(capture('12-own-cursor-after-typing'))
(data / 'projects.json').rmdir()
(data / 'projects.saved.json').rename(data / 'projects.json')
w.save_draft()
QTest.qWait(100)
w.close()
(out / 'reviewer-narrow-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
print(json.dumps(results, ensure_ascii=False, indent=2))
app.quit()
