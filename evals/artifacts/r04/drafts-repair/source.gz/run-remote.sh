#!/usr/bin/env bash
set -euo pipefail
case_dir=$(cd -- "$(dirname -- "$0")" && pwd)
export LD_LIBRARY_PATH="/opt/ui-skill-lab-20261020/round-0002-desktop/native-deps/root/usr/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export QT_QPA_PLATFORM=xcb
export XDG_RUNTIME_DIR="$case_dir/runtime"
mkdir -p "$XDG_RUNTIME_DIR" "$case_dir/evidence"
chmod 700 "$XDG_RUNTIME_DIR"
display_file="$XDG_RUNTIME_DIR/display-$$"
exec 3>"$display_file"
Xvfb -displayfd 3 -screen 0 1440x1000x24 -nolisten tcp -noreset >"$XDG_RUNTIME_DIR/xvfb-$$.log" 2>&1 &
xvfb_pid=$!
exec 3>&-
trap 'kill "$xvfb_pid" 2>/dev/null || true; wait "$xvfb_pid" 2>/dev/null || true; rm -f "$display_file"' EXIT
for attempt in {1..100}; do
  if [[ -s "$display_file" ]]; then break; fi
  sleep 0.1
done
export DISPLAY=":$(cat "$display_file")"
cd "$case_dir"
/opt/ui-skill-lab-20261020/round-0002-desktop/.venv/bin/python "$@"
