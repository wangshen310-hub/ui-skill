"""Before/after reproduction; drives only repair-local data on remote Xvfb."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import traceback

from PySide6.QtCore import Qt, QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QLabel, QMessageBox, QPushButton
from app import NotesWindow

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("phase", choices=["before", "after"])
args = parser.parse_args()
out = ROOT / "evidence" / args.phase
out.mkdir(parents=True, exist_ok=True)
app = QApplication([])
app.setStyle("Fusion")
app.setQuitOnLastWindowClosed(False)
results = []


def log(name, **data):
    item = {"check": name, **data}
    results.append(item)
    print(json.dumps(item, ensure_ascii=False), flush=True)


def settle(ms=160):
    app.processEvents()
    QTest.qWait(ms)


def paste(widget, text):
    widget.setFocus()
    QTest.keyClick(widget, Qt.Key.Key_A, Qt.KeyboardModifier.ControlModifier)
    app.clipboard().setText(text)
    QTest.keyClick(widget, Qt.Key.Key_V, Qt.KeyboardModifier.ControlModifier)
    settle()


def geometry(window):
    editor = window.notes_edit
    caret = editor.cursorRect()
    viewport = editor.viewport().rect()
    return {"cursor": [caret.x(), caret.y(), caret.width(), caret.height()],
            "viewport": [viewport.x(), viewport.y(), viewport.width(), viewport.height()],
            "cursor_fully_visible": viewport.contains(caret), "cursor_intersects": viewport.intersects(caret),
            "notes_height": editor.height(), "window": [window.width(), window.height()],
            "focus": app.focusWidget().objectName() if app.focusWidget() else None,
            "cursor_at_end": editor.textCursor().atEnd(), "scroll": editor.verticalScrollBar().value()}


def discard(window):
    def respond():
        dialog = app.activeModalWidget()
        if isinstance(dialog, QMessageBox):
            dialog.findChild(QPushButton, "discardChanges").click()
    QTimer.singleShot(50, respond)
    window.close()
    settle()


def keyboard_click(button):
    button.setFocus()
    QTest.keyClick(button, Qt.Key.Key_Space)
    settle()


def run():
    sha = hashlib.sha256((ROOT / "app.py").read_bytes()).hexdigest()
    log("source", phase=args.phase, app_sha256=sha)
    if args.phase == "before":
        assert sha == "a4d8481d45d94c60ed960605cd9a0be6eb88338e15081c2aef0c772f77dfac57"
    data = out / "own-narrow-data"
    if data.exists():
        shutil.rmtree(data)
    w = NotesWindow(data)
    w.resize(640, 480)
    w.show()
    w.activateWindow()
    settle()
    QTest.keyClick(w.project_list, Qt.Key.Key_Down)
    QTest.keyClick(w.project_list, Qt.Key.Key_Return)
    settle()
    paste(w.title_edit, "陶器上新 · 周三补拍（补拍灯光、人物站位以及备用机位）")
    notes = "\n".join(f"机位 {i}：核对杯口和壶嘴的光线。" for i in range(1, 71))
    paste(w.notes_edit, notes)
    QTest.keyClick(w.notes_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
    settle()
    QTest.keyClick(w.notes_edit, Qt.Key.Key_End, Qt.KeyboardModifier.ControlModifier)
    QTest.keyClick(w.notes_edit, Qt.Key.Key_Return)
    QTest.keyClicks(w.notes_edit, "END_REPAIR")
    settle()
    w.grab().save(str(out / "01-before-save-failure.png"))
    log("caret-before-error-bar", **geometry(w))
    path = w.store.path
    backup = path.with_name("projects.saved.json")
    old = path.read_bytes()
    path.rename(backup)
    path.mkdir()
    QTest.keyClick(w.notes_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
    settle(200)
    status = geometry(w)
    w.grab().save(str(out / "02-real-save-failure.png"))
    log("caret-after-real-eisdir", **status, raw_error=w.save_error,
        content_preserved=w.notes_edit.toPlainText().endswith("END_REPAIR"),
        original_bytes_preserved=backup.read_bytes() == old)
    assert w.is_dirty() and backup.read_bytes() == old and status["focus"] == "notesEdit"
    if args.phase == "after":
        assert status["cursor_fully_visible"], status
        # Repeating the failure must not move the cursor to some other line.
        before_position = w.notes_edit.textCursor().position()
        QTest.keyClick(w.notes_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
        settle()
        assert w.notes_edit.textCursor().position() == before_position
        assert geometry(w)["cursor_fully_visible"]
    else:
        assert not status["cursor_intersects"], "original caret issue did not reproduce"
    path.rmdir()
    backup.rename(path)
    if args.phase == "after":
        QTest.keyClick(w.notes_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
        settle()
        assert not w.is_dirty() and geometry(w)["cursor_fully_visible"]
        assert json.loads(path.read_text())["projects"][1]["notes"].endswith("END_REPAIR")
        log("recovered-save-keeps-caret", **geometry(w), status=w.state_label.text())
        # Editing the title while reading an earlier part of the notes should
        # not pull the notes viewport to an unrelated, unfocused cursor.
        w.title_edit.setFocus()
        QTest.keyClick(w.title_edit, Qt.Key.Key_End)
        QTest.keyClicks(w.title_edit, " (v2)")
        w.notes_edit.verticalScrollBar().setValue(12)
        reading_scroll = w.notes_edit.verticalScrollBar().value()
        reading_position = w.notes_edit.textCursor().position()
        path.rename(backup)
        path.mkdir()
        QTest.keyClick(w.title_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
        settle()
        assert app.focusWidget() is w.title_edit
        assert w.notes_edit.verticalScrollBar().value() == reading_scroll
        assert w.notes_edit.textCursor().position() == reading_position
        log("unfocused-notes-reading-position-preserved", before_scroll=reading_scroll,
            after_scroll=w.notes_edit.verticalScrollBar().value(), focus=app.focusWidget().objectName(),
            insertion_position_unchanged=True)
        path.rmdir()
        backup.rename(path)
        discard(w)
    else:
        discard(w)

    broken = out / "own-broken-data"
    broken.mkdir(exist_ok=True)
    bad_bytes = b"{bad"
    broken_path = broken / "projects.json"
    broken_path.write_bytes(bad_bytes)
    w = NotesWindow(broken)
    w.show()
    w.activateWindow()
    settle()
    assert w.stack.currentWidget() is w.load_error_page
    labels = [label.text() for label in w.load_error_page.findChildren(QLabel)]
    w.grab().save(str(out / "03-load-failure.png"))
    log("damaged-file-error-page", labels=labels, original_bytes_preserved=broken_path.read_bytes() == bad_bytes)
    assert broken_path.read_bytes() == bad_bytes
    if args.phase == "after":
        assert "Expecting property" not in w.load_error_label.text()
        w.resize(640, 480)
        settle()
        assert w.size().width() == 640 and w.size().height() == 480
        w.grab().save(str(out / "03b-load-failure-narrow.png"))
        # The path field and dedicated copy control are both native keyboard controls.
        w.load_path_edit.setFocus()
        QTest.keyClick(w.load_path_edit, Qt.Key.Key_A, Qt.KeyboardModifier.ControlModifier)
        QTest.keyClick(w.load_path_edit, Qt.Key.Key_C, Qt.KeyboardModifier.ControlModifier)
        settle()
        assert app.clipboard().text() == str(broken_path.resolve())
        log("keyboard-copy-path-field", clipboard=app.clipboard().text(), expected=str(broken_path.resolve()))
        app.clipboard().setText("clipboard sentinel")
        QTest.keyClick(w.load_path_edit, Qt.Key.Key_Tab)
        assert app.focusWidget() is w.load_copy_button
        QTest.keyClick(w.load_copy_button, Qt.Key.Key_Space)
        settle()
        assert app.clipboard().text() == str(broken_path.resolve())
        log("keyboard-copy-button", clipboard=app.clipboard().text(), feedback=w.load_copy_button.text())
        keyboard_click(w.load_details_button)
        assert w.load_diagnostics.isVisible() and "JSONDecodeError" in w.load_diagnostics.toPlainText()
        assert w.size().width() == 640 and w.size().height() == 480
        w.grab().save(str(out / "04-load-failure-diagnostics.png"))
        log("optional-diagnostics", diagnostic=w.load_diagnostics.toPlainText(), visible=True)
        keyboard_click(w.load_details_button)
        assert not w.load_diagnostics.isVisible()
        assert broken_path.read_bytes() == bad_bytes
        keyboard_click(w.load_retry_button)
        assert broken_path.read_bytes() == bad_bytes and w.stack.currentWidget() is w.load_error_page
        # Restore an explicitly known valid copy; application never overwrites bad bytes itself.
        broken_path.write_bytes(path.read_bytes())
        repaired_hash = hashlib.sha256(broken_path.read_bytes()).hexdigest()
        keyboard_click(w.load_retry_button)
        assert w.stack.currentWidget() is w.list_page
        assert app.focusWidget() is w.project_list
        assert hashlib.sha256(broken_path.read_bytes()).hexdigest() == repaired_hash
        log("repair-file-then-keyboard-reload", count=w.project_list.count(), focus=app.focusWidget().objectName(),
            repaired_file_unchanged=True)
        QTest.keyClick(w.project_list, Qt.Key.Key_Down)
        QTest.keyClick(w.project_list, Qt.Key.Key_Return)
        settle()
        expected_title = w.title_edit.text() + " · 核对"
        paste(w.title_edit, expected_title)
        QTest.keyClick(w.title_edit, Qt.Key.Key_Tab)
        assert app.focusWidget() is w.notes_edit
        QTest.keyClick(w.notes_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
        settle()
        QTest.keyClick(w.notes_edit, Qt.Key.Key_Left, Qt.KeyboardModifier.AltModifier)
        settle()
        assert app.focusWidget() is w.project_list and w.project_list.currentRow() == 1
        QTest.keyClick(w.project_list, Qt.Key.Key_Return)
        settle()
        assert w.title_edit.text() == expected_title and not w.is_dirty()
        log("normal-keyboard-save-return-reopen", real_title=json.loads(broken_path.read_text())["projects"][1]["title"],
            expected_title=expected_title, title_restored=True, focus=app.focusWidget().objectName())
        w.grab().save(str(out / "05-normal-reopened.png"))
    w.close()
    log("complete", phase=args.phase, passed=True)


try:
    run()
except Exception:
    log("FAILED", traceback=traceback.format_exc())
    raise
finally:
    (out / "raw-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
