# 拍摄备注：案例修复副本

本目录只修复已评审原案例的两个错误状态问题，沿用原有两张生成且查看过的参考图。它不是独立新生成回归案例。

腾讯云已有环境中运行：

```bash
cd /opt/ui-skill-lab-20261020/round-0004-drafts-repair
./run-remote.sh app.py --data-dir ./demo-data
```

修后相关验收：

```bash
./run-remote.sh repair_probe.py after
```

驱动只重建本目录 evidence/after/own-* 数据；会制造并恢复真实 EISDIR。修前证据在 evidence/before/，对应原源码在 before/app.py；请勿用修后源码重跑并覆盖修前结果。最终冻结源码在 frozen/，哈希见 SHA256SUMS。

读取错误时可以在只读位置框中 Ctrl+A/Ctrl+C，也可 Tab 到“复制位置”后按 Space；“查看诊断信息”按需展开原始异常。应用不会自动覆盖或重置损坏文件。
