# 轨道航行 R4 源码

需 Python 3.11、Pygame 2.6.1、SDL/X11、Noto CJK 中文字体和 DejaVu Sans；验收另需 Xvfb、xdotool。包内不含依赖和字体文件。

腾讯云现有环境运行：

```sh
cd /opt/ui-skill-lab-20261020/round-0003-game
/opt/ui-skill-validation-20261020/venv/bin/python app.py
```

需图形显示会话。初始暂停，上下或 Tab/Shift+Tab 选择、Enter/Space 确认、Esc 暂停/继续或返回设置上一级，左右调整设置。标题页仅显示可用操作。设置写入同目录 `settings.json`。

无显示器时，验收自行启动并清理私有 Xvfb；必须使用新的空输出目录：

```sh
PYTHONDONTWRITEBYTECODE=1 /opt/ui-skill-validation-20261020/venv/bin/python acceptance.py --output-dir evidence/readability-r4/new-run
```

按键提示、保存提示和右上状态按实际窗口像素绘制，辅助中文18px、键帽16px，不随场景缩小。每张截图事件附有实际字形墨迹矩形及字体路径。键盘/窗口操作通过X服务器，手柄事件为明确标记的测试合成输入，不代表实体设备验证。
