"""Verify the actual app.py entry point in its own OS process on private Xvfb."""
import json
from pathlib import Path
import subprocess
import sys
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

root = Path(__file__).resolve().parent
app = QApplication([])
with (root / "evidence/standalone-console.log").open("w") as log:
    process = subprocess.Popen([sys.executable, str(root / "app.py"), "--data-dir", str(root / "demo-data")],
                               cwd=root, stdout=log, stderr=log)
    try:
        QTest.qWait(1200)
        assert process.poll() is None, "app.py exited during launch"
        app.primaryScreen().grabWindow(0).save(str(root / "evidence/13-standalone-screen.png"))
        data = json.loads((root / "demo-data/projects.json").read_text())
        assert len(data["projects"]) == 3
        evidence = {"entrypoint": "app.py --data-dir demo-data", "pid": process.pid,
                    "running_during_capture": True, "local_sample_count": 3,
                    "screen": [app.primaryScreen().size().width(), app.primaryScreen().size().height()]}
    finally:
        process.terminate()
        process.wait(timeout=5)
    evidence["own_process_stopped"] = process.poll() is not None
    (root / "evidence/standalone-raw.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(evidence, ensure_ascii=False))
