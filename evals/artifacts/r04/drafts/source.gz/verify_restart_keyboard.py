"""A second OS process opens persisted drafts and exercises native keyboard exits."""
import hashlib
import json
import os
from pathlib import Path
import shutil

from PySide6.QtCore import Qt, QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QMessageBox, QPushButton
from app import NotesWindow

ROOT = Path(__file__).resolve().parent
evidence = ROOT / "evidence"
app = QApplication([])
app.setStyle("Fusion")
app.setQuitOnLastWindowClosed(False)
results = []


def log(name, **data):
    row = {"check": name, **data}
    results.append(row)
    print(json.dumps(row, ensure_ascii=False), flush=True)


def settle():
    app.processEvents()
    QTest.qWait(120)


def choose_key(trigger, key):
    found = []
    def respond():
        dialog = app.activeModalWidget()
        assert isinstance(dialog, QMessageBox)
        found.append(dialog.defaultButton().text())
        QTest.keyClick(dialog, key)
    QTimer.singleShot(80, respond)
    trigger()
    settle()
    assert found
    return found[0]


def choose_button(trigger, name):
    found = []
    def respond():
        dialog = app.activeModalWidget()
        assert isinstance(dialog, QMessageBox)
        target = dialog.findChild(QPushButton, name)
        found.append(target.text())
        QTest.mouseClick(target, Qt.MouseButton.LeftButton)
    QTimer.singleShot(80, respond)
    trigger()
    settle()
    assert found
    return found[0]


window = NotesWindow(ROOT / "verification-data")
window.show()
window.activateWindow()
settle()
QTest.keyClick(window.project_list, Qt.Key.Key_Return)
settle()
assert window.title_edit.text() == "秋季人像 · 河岸外景（已确认机位）"
assert window.notes_edit.toPlainText().endswith("写入失败时这段备注仍应保留。")
log("independent-process-reload", pid=os.getpid(), file=str(window.store.path), title=window.title_edit.text(),
    notes=window.notes_edit.toPlainText(), sha256=hashlib.sha256(window.store.path.read_bytes()).hexdigest())
window.close()

# Keyboard-specific mutations remain separate from the main acceptance data.
data = ROOT / "keyboard-data"
if data.exists():
    shutil.rmtree(data)
data.mkdir()
shutil.copy2(ROOT / "verification-data/projects.json", data / "projects.json")
window = NotesWindow(data)
window.show()
window.activateWindow()
settle()
QTest.keyClick(window.project_list, Qt.Key.Key_Down)
assert window.project_list.currentRow() == 1
QTest.keyClick(window.project_list, Qt.Key.Key_Tab)
assert app.focusWidget() is window.open_button
QTest.keyClick(window.open_button, Qt.Key.Key_Space)
settle()
assert window.current_id == "ceramics-still-life"
assert app.focusWidget() is window.title_edit
log("tab-space-open-second-project", title=window.title_edit.text(), focus=app.focusWidget().objectName())

window.title_edit.setFocus()
QTest.keyClick(window.title_edit, Qt.Key.Key_End)
QTest.keyClicks(window.title_edit, " (v2)")
assert window.is_dirty()
default = choose_key(lambda: QTest.keyClick(window.title_edit, Qt.Key.Key_Escape), Qt.Key.Key_Escape)
assert window.is_dirty() and window.stack.currentWidget() is window.editor_page
assert app.focusWidget() is window.title_edit
log("escape-cancels-unsaved-return", default=default, input_preserved=window.title_edit.text().endswith(" (v2)"))
default = choose_key(window.close, Qt.Key.Key_Return)
assert window.isVisible() and window.is_dirty()
assert app.focusWidget() is window.title_edit
log("enter-default-keeps-editing", default=default, window_open=True)
selected = choose_button(lambda: QTest.keyClick(window.title_edit, Qt.Key.Key_Left, Qt.KeyboardModifier.AltModifier), "saveAndLeave")
assert window.stack.currentWidget() is window.list_page
assert app.focusWidget() is window.project_list and window.project_list.currentRow() == 1
disk = json.loads(window.store.path.read_text())["projects"]
assert disk[1]["title"].endswith(" (v2)")
log("save-and-return-success", button=selected, real_file_updated=True, focus=app.focusWidget().objectName(), selection=1)

QTest.keyClick(window.project_list, Qt.Key.Key_Return)
settle()
window.notes_edit.setFocus()
QTest.keyClick(window.notes_edit, Qt.Key.Key_End, Qt.KeyboardModifier.ControlModifier)
QTest.keyClicks(window.notes_edit, " saved-on-close")
selected = choose_button(window.close, "saveAndLeave")
assert not window.isVisible()
assert json.loads(window.store.path.read_text())["projects"][1]["notes"].endswith(" saved-on-close")
log("save-and-close-success", button=selected, window_closed=True, real_file_updated=True)
(evidence / "restart-keyboard-raw.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
