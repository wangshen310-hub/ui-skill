# 拍摄备注

原生 PySide6 本地桌面工具。首次运行将 samples.json 中的三个明确样例写入指定数据文件夹，不联网。

运行（已有获准复用的环境）：

```bash
cd /opt/ui-skill-lab-20261020/round-0004-drafts
./run-remote.sh app.py --data-dir ./demo-data
```

run-remote.sh 创建私有 Xvfb，退出时清理自己的显示进程。交互使用时可在有桌面的环境直接运行 `python app.py --data-dir ./demo-data`；依赖见 requirements.txt，本案例未全局安装依赖。默认数据位置为 XDG_DATA_HOME/shooting-notes，未设置 XDG_DATA_HOME 时是 ~/.local/share/shooting-notes。本次运行均显式使用案例目录内的数据。

键盘：清单 ↑/↓ 选择，Enter 打开；Tab、Shift+Tab 移动焦点；打开按钮支持 Space；Ctrl+S 保存；Alt+Left 或 Escape 返回。编辑内容尚未保存时，返回与关闭均可保存、明确放弃或继续编辑；确认框默认继续编辑，Escape 也继续编辑。保存失败保留输入，可重试或明确放弃后离开。

文件是 UTF-8 projects.json，保存采用同文件夹临时文件、fsync 后原子替换。标题不能为空。没有后台自动保存、云同步、项目创建/删除或多进程冲突合并。

验收在腾讯云私有 Xvfb 上执行：

```bash
./run-remote.sh verify.py
./run-remote.sh verify_restart_keyboard.py
./run-remote.sh capture_standalone.py
```

验收会重建案例内的 verification-data、keyboard-data 和 verification-broken；不会读取默认个人数据。真实写入失败通过把隔离项目文件的位置临时设为同名目录制造，完成后恢复。

references/ 是生成并查看的参考图；initial/ 是首次可运行版本、截图与首轮失败原始记录；evidence/ 保存最终截图、行为原始结果与控制台输出。短报告见 report.md，文件哈希见 SHA256SUMS。
