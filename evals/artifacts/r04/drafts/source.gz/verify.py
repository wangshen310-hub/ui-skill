"""Drive the real native Qt window; all files are case-local test data."""
import json
import hashlib
import os
from pathlib import Path
import shutil
import sys
import traceback

import PySide6
from PySide6.QtCore import Qt, QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QMessageBox, QPushButton

from app import NotesWindow

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
EVIDENCE.mkdir(exist_ok=True)
DATA = ROOT / "verification-data"
RESULTS = []
APP = QApplication.instance() or QApplication([])
APP.setStyle("Fusion")
APP.setQuitOnLastWindowClosed(False)


def record(name, **details):
    result = {"check": name, **details}
    RESULTS.append(result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


def settle():
    APP.processEvents()
    QTest.qWait(100)


def screenshot(window, name):
    settle()
    path = EVIDENCE / name
    assert window.grab().save(str(path)), name
    return name


def paste(widget, text):
    widget.setFocus()
    QTest.keyClick(widget, Qt.Key.Key_A, Qt.KeyboardModifier.ControlModifier)
    APP.clipboard().setText(text)
    QTest.keyClick(widget, Qt.Key.Key_V, Qt.KeyboardModifier.ControlModifier)
    settle()


def click(widget):
    QTest.mouseClick(widget, Qt.MouseButton.LeftButton)
    settle()


def modal_action(window, trigger, object_name, image_name=None):
    observed = {}
    def choose():
        dialog = APP.activeModalWidget()
        if not isinstance(dialog, QMessageBox):
            observed["error"] = "expected visible QMessageBox"
            return
        observed["title"] = dialog.windowTitle()
        observed["message"] = dialog.text()
        observed["buttons"] = [b.text() for b in dialog.buttons()]
        observed["default"] = dialog.defaultButton().text()
        observed["escape"] = dialog.escapeButton().text()
        if image_name:
            screenshot(window, image_name)
            dialog.grab().save(str(EVIDENCE / ("dialog-" + image_name)))
        target = dialog.findChild(QPushButton, object_name)
        if target is None:
            observed["error"] = "missing button " + object_name
            dialog.reject()
        else:
            click(target)
    QTimer.singleShot(80, choose)
    trigger()
    settle()
    assert "error" not in observed, observed
    assert observed, "No modal dialog opened"
    return observed


def visible_rects(window, widgets):
    return {w.objectName(): {"visible": w.isVisible(), "size": [w.width(), w.height()],
                           "inside_window": window.rect().contains(w.mapTo(window, w.rect().topLeft())) and
                                            window.rect().contains(w.mapTo(window, w.rect().bottomRight()))}
            for w in widgets}


def run():
    if DATA.exists():
        shutil.rmtree(DATA)
    window = NotesWindow(DATA)
    window.show()
    window.activateWindow()
    settle()
    record("environment", hostname=os.uname().nodename, python=sys.executable,
           pyside=PySide6.__version__, display=os.environ.get("DISPLAY"), platform=APP.platformName(),
           font=window.font().family(), size=[window.width(), window.height()],
           app_sha256=hashlib.sha256((ROOT / "app.py").read_bytes()).hexdigest())
    assert window.project_list.count() == 3
    assert APP.focusWidget() is window.project_list
    screenshot(window, "01-list-initial.png")
    QTest.keyClick(window.project_list, Qt.Key.Key_Down)
    assert window.project_list.currentRow() == 1
    QTest.keyClick(window.project_list, Qt.Key.Key_Up)
    QTest.keyClick(window.project_list, Qt.Key.Key_Return)
    settle()
    assert window.stack.currentWidget() is window.editor_page
    assert APP.focusWidget() is window.title_edit
    screenshot(window, "02-editor-initial.png")
    record("open-list-with-keyboard", count=3, selected=window.current_id, focus=APP.focusWidget().objectName())
    # Save initial runnable source before any acceptance-driven revision.
    initial = ROOT / "initial"
    initial.mkdir(exist_ok=True)
    for name in ("app.py", "samples.json", "run-remote.sh", "design.md"):
        destination = initial / name
        if not destination.exists():
            shutil.copy2(ROOT / name, destination)
    for name in ("01-list-initial.png", "02-editor-initial.png"):
        destination = initial / name
        if not destination.exists():
            shutil.copy2(EVIDENCE / name, destination)

    title = "秋季人像 · 河岸外景（已确认机位）"
    notes = window.notes_edit.toPlainText() + "\n补充：桥边先拍横幅，反光板由小陈协助。"
    paste(window.title_edit, title)
    QTest.keyClick(window.title_edit, Qt.Key.Key_Tab)
    assert APP.focusWidget() is window.notes_edit
    paste(window.notes_edit, notes)
    assert window.is_dirty() and "未保存" in window.state_label.text()
    screenshot(window, "03-editor-dirty.png")
    QTest.keyClick(window.notes_edit, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
    settle()
    on_disk = json.loads(window.store.path.read_text())
    assert on_disk["projects"][0]["title"] == title
    assert on_disk["projects"][0]["notes"] == notes
    assert not window.is_dirty() and "已保存到本机" in window.state_label.text()
    screenshot(window, "04-editor-saved.png")
    record("ctrl-s-real-file-save", file=str(window.store.path), title=title, notes=notes,
           status=window.state_label.text(), saved_at=on_disk["projects"][0]["saved_at"])

    QTest.keyClick(window.notes_edit, Qt.Key.Key_Left, Qt.KeyboardModifier.AltModifier)
    settle()
    assert window.stack.currentWidget() is window.list_page
    assert window.project_list.currentRow() == 0
    assert APP.focusWidget() is window.project_list
    QTest.keyClick(window.project_list, Qt.Key.Key_Return)
    settle()
    assert window.title_edit.text() == title and window.notes_edit.toPlainText() == notes
    assert window.notes_edit.verticalScrollBar().value() == 0
    QTest.keyClick(window.title_edit, Qt.Key.Key_Tab, Qt.KeyboardModifier.ShiftModifier)
    assert APP.focusWidget() is window.save_button
    record("return-reopen-focus", selection=0, saved_values_restored=True, shift_tab_focus=APP.focusWidget().objectName())

    # Content growth and responsive native window geometry.
    long_title = "河岸外景拍摄安排与补拍清单（需与摄影助理核对灯光、服装、人物站位以及日落后的备用机位）" * 3
    long_notes = "\n".join(f"机位 {i}：检查反光板方向和人物面部的光线。" for i in range(1, 91))
    paste(window.title_edit, long_title)
    paste(window.notes_edit, long_notes)
    window.resize(640, 480)
    settle()
    assert window.notes_edit.verticalScrollBar().maximum() > 0
    geometry = visible_rects(window, [window.back_button, window.save_button, window.title_edit, window.notes_edit, window.state_label])
    assert all(d["visible"] and d["inside_window"] for d in geometry.values()), geometry
    screenshot(window, "05-editor-narrow-long.png")
    record("narrow-long-editor", size=[window.width(), window.height()], notes_lines=90, title_chars=len(long_title), geometry=geometry)
    info = modal_action(window, lambda: click(window.back_button), "continueEditing", "06-unsaved-return.png")
    assert window.stack.currentWidget() is window.editor_page and window.notes_edit.toPlainText() == long_notes
    record("unsaved-return-continue", **info)
    info = modal_action(window, lambda: click(window.back_button), "discardChanges")
    assert window.stack.currentWidget() is window.list_page and APP.focusWidget() is window.project_list, (window.stack.currentWidget().objectName(), str(APP.focusWidget()), str(APP.activeWindow()))
    screenshot(window, "07-list-narrow.png")
    record("unsaved-return-discard", disk_unchanged=json.loads(window.store.path.read_text())["projects"][0]["title"] == title, **info)
    QTest.keyClick(window.project_list, Qt.Key.Key_Return)
    settle()
    assert window.title_edit.text() == title and window.notes_edit.toPlainText() == notes
    window.resize(1180, 780)
    settle()

    # Manufacture a genuine operating-system write failure, not a mocked save.
    backup = DATA / "projects.saved.json"
    window.store.path.rename(backup)
    window.store.path.mkdir()
    changed = notes + "\n写入失败时这段备注仍应保留。"
    paste(window.notes_edit, changed)
    click(window.save_button)
    assert window.is_dirty() and window.error_frame.isVisible()
    assert "失败" in window.state_label.text()
    assert window.notes_edit.toPlainText() == changed
    screenshot(window, "08-real-write-failure.png")
    record("real-filesystem-save-failure", cause="destination projects.json is a directory; os.replace raises EISDIR",
           status=window.state_label.text(), error=window.error_label.text(), raw_os_error=window.save_error, input_preserved=True,
           original_sha256=hashlib.sha256(backup.read_bytes()).hexdigest())
    click(window.retry_button)
    assert window.is_dirty() and window.error_frame.isVisible()
    record("failed-retry-keeps-input", preserved=window.notes_edit.toPlainText() == changed)
    info = modal_action(window, lambda: click(window.back_button), "saveAndLeave", "09-failure-return-dialog.png")
    assert window.stack.currentWidget() is window.editor_page and window.is_dirty()
    record("save-and-return-failure-stays-editor", input_preserved=window.notes_edit.toPlainText() == changed, **info)
    info = modal_action(window, lambda: click(window.back_button), "continueEditing")
    assert window.notes_edit.toPlainText() == changed and window.is_dirty()
    record("failed-save-return-cancel", **info)
    info = modal_action(window, lambda: click(window.back_button), "discardChanges")
    assert window.stack.currentWidget() is window.list_page and APP.focusWidget() is window.project_list
    assert window.store.path.is_dir()
    record("failed-save-return-discard", leaves_editor=True, no_write_attempt=True, **info)
    window.store.path.rmdir()
    backup.rename(window.store.path)

    # Retry after repairing destination must write the retained edits.
    QTest.keyClick(window.project_list, Qt.Key.Key_Return)
    settle()
    assert window.notes_edit.toPlainText() == notes
    paste(window.notes_edit, changed)
    window.store.path.rename(backup)
    window.store.path.mkdir()
    click(window.save_button)
    window.store.path.rmdir()
    backup.rename(window.store.path)
    click(window.retry_button)
    assert not window.is_dirty() and not window.error_frame.isVisible()
    assert json.loads(window.store.path.read_text())["projects"][0]["notes"] == changed
    record("failure-repaired-retry-success", status=window.state_label.text(), real_file_matches=True)

    # The same failure must not trap application close.
    paste(window.notes_edit, changed + "\n关闭前尚未保存。")
    window.store.path.rename(backup)
    window.store.path.mkdir()
    info = modal_action(window, window.close, "saveAndLeave", "10-failure-close-dialog.png")
    assert window.isVisible() and window.is_dirty()
    record("close-save-fails-stays-open", status=window.state_label.text(), **info)
    info = modal_action(window, window.close, "continueEditing")
    assert window.isVisible() and window.is_dirty()
    record("close-failure-continue", **info)
    info = modal_action(window, window.close, "discardChanges")
    assert not window.isVisible()
    record("close-failure-discard-exits", exited=True, **info)
    window.store.path.rmdir()
    backup.rename(window.store.path)

    # A new native window reloads the on-disk data rather than old widgets.
    window = NotesWindow(DATA)
    window.show()
    window.activateWindow()
    settle()
    QTest.keyClick(window.project_list, Qt.Key.Key_Return)
    settle()
    assert window.title_edit.text() == title and window.notes_edit.toPlainText() == changed
    record("new-window-disk-reload", title=window.title_edit.text(), retained_last_successful_save=True)
    screenshot(window, "11-editor-after-reload.png")
    # Empty title is actionable and does not overwrite a good file.
    old_bytes = window.store.path.read_bytes()
    paste(window.title_edit, "   ")
    click(window.save_button)
    assert window.store.path.read_bytes() == old_bytes
    assert "填写项目标题" in window.error_label.text()
    assert APP.focusWidget() is window.title_edit
    record("empty-title-validation", file_unchanged=True, focus="titleEdit", text=window.error_label.text())
    modal_action(window, window.close, "discardChanges")
    # Startup failure preserves an invalid original file and can retry.
    broken = ROOT / "verification-broken"
    broken.mkdir(exist_ok=True)
    (broken / "projects.json").write_text("{invalid", encoding="utf-8")
    bad = NotesWindow(broken)
    bad.show()
    settle()
    assert bad.stack.currentWidget() is bad.load_error_page
    assert (broken / "projects.json").read_text() == "{invalid"
    screenshot(bad, "12-load-error.png")
    shutil.copy2(DATA / "projects.json", broken / "projects.json")
    bad.load_projects()
    settle()
    assert bad.stack.currentWidget() is bad.list_page
    record("startup-load-error-retry", original_preserved=True, retry_loaded=True)
    bad.close()
    record("finished", checks=len(RESULTS), status="passed")


if __name__ == "__main__":
    try:
        run()
    except Exception:
        record("FAILED", traceback=traceback.format_exc())
        raise
    finally:
        (EVIDENCE / "behavior-raw.json").write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2), encoding="utf-8")
