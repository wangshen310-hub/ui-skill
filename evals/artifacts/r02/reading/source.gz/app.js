const articles = [
  { title: '在街角，慢下来', paragraphs: [
    '拐过路口，车声渐渐远了。早餐店刚收起门口的小桌，锅铲还搁在灶边。店主提着水桶出来，把台阶冲了一遍，水沿着石板缝流向街边。',
    '再往前走，墙边停着两辆自行车。一扇木门半开着，门上贴着褪色的门牌。树影落在门口的空椅子上，风一吹，又挪开一点。'
  ] },
  { title: '巷子尽头的早餐', paragraphs: [
    '清晨七点，店主把木凳搬到门口。汤锅的热气贴着窗玻璃往上走，面条在漏勺里抖了一下，落进一只白瓷碗。',
    '有人带走一份早餐，有人坐下来慢慢吃。靠墙的桌上放着一份报纸，翻到一半，压着一双还没拆开的筷子。这里的一天，从一碗热汤开始。'
  ] },
  { title: '让树木重回街道', paragraphs: [
    '走到路口时，风先穿过树叶，再落到肩上。树池边的石沿留下了坐过的痕迹，旁边停着两辆自行车。',
    '一条街道的舒适，有时就藏在这些细小的地方：可以停留的阴凉、能够坐下的边角，以及从这里走到下一个路口的从容。'
  ] }
];
const $ = id => document.getElementById(id);
const storageKey = 'streets-between-bookmarks-v1';
const mobile = matchMedia('(max-width: 760px)');
let saved = new Set(), filter = 'all', current = 0, menuOpen = false, noticeTimer, helpOpener;
try { const data = JSON.parse(localStorage.getItem(storageKey) || '[]'); if (Array.isArray(data)) saved = new Set(data.filter(i => Number.isInteger(i) && i >= 0 && i < articles.length)); } catch {}
function indexFromHash() { const match = location.hash.match(/^#essay-([1-3])$/); return match ? Number(match[1]) - 1 : 0; }
const bookmarkSvg = '<svg class="toc-bookmarked" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h12v18l-6-4-6 4z"/></svg><span class="sr-only">，已收藏</span>';
function renderToc() {
  const list = $('toc-list');
  const focusedIndex = document.activeElement?.closest('.toc-item')?.dataset.index;
  list.replaceChildren();
  articles.forEach((article, index) => {
    if (filter === 'saved' && !saved.has(index)) return;
    const li = document.createElement('li'), button = document.createElement('button');
    button.className = 'toc-item'; button.dataset.index = index;
    if (current === index) button.setAttribute('aria-current', 'true');
    button.innerHTML = `<span class="toc-number">${String(index + 1).padStart(2, '0')}</span><span class="toc-title"></span>${saved.has(index) ? bookmarkSvg : ''}`;
    button.querySelector('.toc-title').textContent = article.title;
    button.addEventListener('click', () => selectArticle(index));
    li.append(button); list.append(li);
  });
  $('saved-count').textContent = saved.size ? String(saved.size) : '';
  $('empty-state').hidden = filter !== 'saved' || saved.size > 0;
  $('toc-label').textContent = filter === 'saved' ? '已收藏' : '目录';
  $('toc-panel').setAttribute('aria-labelledby', filter === 'all' ? 'tab-all' : 'tab-saved');
  if (focusedIndex !== undefined) (list.querySelector(`[data-index="${focusedIndex}"]`) || list.querySelector('button') || $(`tab-${filter}`)).focus({ preventScroll: true });
}
function renderArticle() {
  const article = articles[current];
  document.title = `${article.title} · 街巷之间`;
  $('article-title').textContent = article.title;
  $('article-body').replaceChildren(...article.paragraphs.map(text => { const p = document.createElement('p'); p.textContent = text; return p; }));
  $('article-number').textContent = String(current + 1).padStart(2, '0');
  $('bookmark').setAttribute('aria-pressed', String(saved.has(current)));
  $('bookmark-label').textContent = saved.has(current) ? '已收藏' : '收藏';
  $('previous').disabled = current === 0; $('next').disabled = current === articles.length - 1;
  $('previous-title').textContent = articles[current - 1]?.title || '';
  $('next-title').textContent = articles[current + 1]?.title || '';
  $('previous').setAttribute('aria-label', articles[current - 1] ? `上一篇：${articles[current - 1].title}` : '上一篇，已是第一篇');
  $('next').setAttribute('aria-label', articles[current + 1] ? `下一篇：${articles[current + 1].title}` : '下一篇，已是最后一篇');
  $('page-number').textContent = `${current + 1} / ${articles.length}`;
  $('page-number').setAttribute('aria-label', `第 ${current + 1} 篇，共 ${articles.length} 篇`);
  renderToc();
}
function selectArticle(index, { history = true, focus = true } = {}) {
  if (index < 0 || index >= articles.length) return;
  current = index;
  if (history && location.hash !== `#essay-${index + 1}`) window.history.pushState({}, '', `#essay-${index + 1}`);
  if (menuOpen) closeMenu(false);
  renderArticle();
  if (focus) { $('article-title').focus({ preventScroll: true }); window.scrollTo(0, 0); }
}
function notify(message) {
  clearTimeout(noticeTimer); $('notice').textContent = message; $('notice').classList.add('visible');
  noticeTimer = setTimeout(() => $('notice').classList.remove('visible'), 3200);
}
function toggleBookmark() {
  const wasSaved = saved.has(current);
  if (wasSaved) saved.delete(current); else saved.add(current);
  let persisted = true;
  try { localStorage.setItem(storageKey, JSON.stringify([...saved])); } catch { persisted = false; }
  $('bookmark').setAttribute('aria-pressed', String(!wasSaved));
  $('bookmark-label').textContent = wasSaved ? '收藏' : '已收藏';
  renderToc();
  notify(persisted ? (wasSaved ? '已取消收藏' : '已收藏到此设备') : '浏览器无法保存，收藏仅在本次打开有效。');
}
function setFilter(value) {
  filter = value;
  ['all', 'saved'].forEach(item => { const tab = $(`tab-${item}`); tab.setAttribute('aria-selected', String(item === value)); tab.tabIndex = item === value ? 0 : -1; });
  renderToc();
}
function openMenu() {
  if (!mobile.matches) return;
  menuOpen = true; $('sidebar').classList.add('open'); $('sidebar').setAttribute('role', 'dialog'); $('sidebar').setAttribute('aria-modal', 'true');
  $('menu-toggle').setAttribute('aria-expanded', 'true'); $('backdrop').hidden = false; document.body.classList.add('menu-open');
  $('main').inert = true; $('mobile-header').inert = true; $('close-menu').focus({ preventScroll: true });
}
function closeMenu(restore = true) {
  menuOpen = false; $('sidebar').classList.remove('open'); $('sidebar').removeAttribute('role'); $('sidebar').removeAttribute('aria-modal');
  $('menu-toggle').setAttribute('aria-expanded', 'false'); $('backdrop').hidden = true; document.body.classList.remove('menu-open');
  $('main').inert = false; $('mobile-header').inert = false;
  if (restore && mobile.matches) $('menu-toggle').focus({ preventScroll: true });
}
function openHelp() {
  helpOpener = document.activeElement;
  $('help-dialog').showModal(); $('close-help').focus();
}
$('bookmark').addEventListener('click', toggleBookmark);
$('previous').addEventListener('click', () => selectArticle(current - 1));
$('next').addEventListener('click', () => selectArticle(current + 1));
$('tab-all').addEventListener('click', () => setFilter('all'));
$('tab-saved').addEventListener('click', () => setFilter('saved'));
for (const value of ['all', 'saved']) $(`tab-${value}`).addEventListener('keydown', event => {
  if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
  event.preventDefault(); event.stopPropagation();
  const target = event.key === 'Home' ? 'all' : event.key === 'End' ? 'saved' : value === 'all' ? 'saved' : 'all';
  setFilter(target); $(`tab-${target}`).focus();
});
$('menu-toggle').addEventListener('click', openMenu); $('close-menu').addEventListener('click', () => closeMenu()); $('backdrop').addEventListener('click', () => closeMenu());
$('keyboard-help').addEventListener('click', openHelp); $('close-help').addEventListener('click', () => $('help-dialog').close());
$('help-dialog').addEventListener('keydown', event => { if (event.key === 'Tab') { event.preventDefault(); $('close-help').focus(); } });
$('help-dialog').addEventListener('close', () => { if (helpOpener?.isConnected) helpOpener.focus({ preventScroll: true }); });
$('help-dialog').addEventListener('click', event => { if (event.target === $('help-dialog')) { const box = event.target.getBoundingClientRect(); if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) event.target.close(); } });
mobile.addEventListener('change', () => { if (menuOpen) closeMenu(false); });
window.addEventListener('popstate', () => selectArticle(indexFromHash(), { history: false }));
window.addEventListener('hashchange', () => selectArticle(indexFromHash(), { history: false }));
document.addEventListener('keydown', event => {
  if ($('help-dialog').open) return;
  if (menuOpen) {
    if (event.key === 'Escape') { event.preventDefault(); closeMenu(); return; }
    if (event.key === 'Tab') {
      const controls = [...$('sidebar').querySelectorAll('button:not([disabled])')].filter(el => el.tabIndex >= 0 && el.getClientRects().length);
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    return;
  }
  if ($('help-dialog').open || event.altKey || event.ctrlKey || event.metaKey || event.target.closest('input, textarea, select, [contenteditable="true"], [role="tablist"]')) return;
  if (event.key === 'ArrowLeft') { event.preventDefault(); selectArticle(current - 1); }
  if (event.key === 'ArrowRight') { event.preventDefault(); selectArticle(current + 1); }
  if (event.key.toLowerCase() === 'b') { event.preventDefault(); toggleBookmark(); }
  if (event.key === '?') { event.preventDefault(); openHelp(); }
});
selectArticle(indexFromHash(), { history: false, focus: false });
