import { cp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
await rm('dist', { recursive: true, force: true });
await mkdir('dist/fonts/files', { recursive: true });
for (const file of ['index.html', 'styles.css', 'app.js']) await cp(file, `dist/${file}`);
const fontRoot = 'node_modules/@fontsource/noto-serif-sc';
const fonts = new Set();
for (const file of ['400.css', '600.css']) {
  const css = await readFile(`${fontRoot}/${file}`, 'utf8');
  await writeFile(`dist/fonts/${file}`, css);
  for (const match of css.matchAll(/url\(['"]?(\.\/files\/[^)'"\s]+)['"]?\)/g)) fonts.add(match[1]);
}
for (const file of fonts) await cp(`${fontRoot}/${file}`, `dist/fonts/${file}`);
await cp(`${fontRoot}/LICENSE`, 'dist/fonts/LICENSE');
console.log(`Built reader to dist/ with ${fonts.size} referenced local font files.`);
