import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
const root = resolve('dist');
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.woff2': 'font/woff2', '.woff': 'font/woff' };
const server = http.createServer(async (req, res) => {
  const path = resolve(root, '.' + decodeURIComponent(new URL(req.url, 'http://localhost').pathname));
  if (path !== root && !path.startsWith(root + '/')) { res.writeHead(403).end(); return; }
  try {
    const data = await readFile(path === root ? resolve(root, 'index.html') : path);
    res.writeHead(200, { 'Content-Type': types[extname(path)] || (path === root ? types['.html'] : 'application/octet-stream'), 'Cache-Control': 'no-store' });
    res.end(data);
  } catch { res.writeHead(404).end('Not found'); }
});
server.listen(18865, '127.0.0.1', () => console.log('Reader preview http://127.0.0.1:18865'));
