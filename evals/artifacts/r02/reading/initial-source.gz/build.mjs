import { cp, mkdir, rm } from 'node:fs/promises';
await rm('dist', { recursive: true, force: true });
await mkdir('dist/fonts', { recursive: true });
for (const file of ['index.html', 'styles.css', 'app.js']) await cp(file, `dist/${file}`);
for (const file of ['400.css', '600.css', 'files']) {
  await cp(`node_modules/@fontsource/noto-serif-sc/${file}`, `dist/fonts/${file}`, { recursive: true });
}
console.log('Built reader to dist/ with local Chinese serif fonts.');
