# 同名文件冲突组件

技能固定版本：a5eb2ab。需求见 `BRIEF.md`；设计与所选参考见 `DESIGN.md`、`evidence/reference.png`。

可复用入口是 `src/conflict-dialog.js` 导出的 `FileConflictDialog` Web Component；`src/demo.js` 仅是最小演示宿主，`server.mjs` 仅处理本案例的隔离样例文件。

腾讯云复现（Node 20，无第三方 npm 依赖）：

```bash
cd /opt/ui-skill-lab-20261020/round-0002-conflict
bash scripts/preview.sh
TMPDIR="$PWD/runtime" /opt/social-auto-upload/.venv/bin/python scripts/browser-check.py --label repeat
bash scripts/stop.sh
```

预览只监听 `127.0.0.1:18863`。可通过 SSH 的本地端口转发打开浏览器，不需要公网监听。

接入现有 Web 文件管理器时，导入组件模块与相应样式规则，并将宿主的文件操作传给 `showConflict`；组件本身不读取任意系统路径。当前样式文件也包含演示宿主规则，接入既有设计系统时应只保留 `file-conflict-dialog` 所用规则与所需字体/按钮 tokens，避免覆盖宿主全局样式。

```js
import './conflict-dialog.js';
const result = await document.querySelector('file-conflict-dialog').showConflict({
  name: '完整文件名.md',
  copyName: '完整文件名（副本）.md',
  existing: { path: '项目资料', modified: '2026-10-18T08:24:00Z', bytes: 152, text: '现有文本' },
  incoming: { path: '下载', modified: '2026-10-20T02:08:00Z', bytes: 158, text: '传入文本' }
}, async (choice, details) => {
  // choice 为 keep / replace / skip。等待宿主真实完成文件操作再返回。
  // 操作失败抛 Error，弹窗会保留比较内容并展示错误。
  return await fileManager.resolveConflict(choice, details);
});
// 取消返回 { choice: 'cancel' }，不会调用文件操作。
```

演示文件位于 `fixtures/项目资料`、`fixtures/下载`，均为此案例创建的 Markdown 样例。结束时保留了“保留两者”的真实结果：原有文件与传入内容副本同时存在。`evidence/final-final-disk.json` 记录文件名、字节数、SHA-256 和完整内容。

初始实现保存在 `original/`，初始截图为 `evidence/original-*.png`。最终实现为 `src/`、`server.mjs`，远端构建输出为 `dist/`；完整结果见 `REPORT.md`。
