#!/usr/bin/env bash
set -euo pipefail
cd /opt/ui-skill-lab-20261020/round-0002-conflict
if [[ -f runtime/preview.pid ]]; then
  preview_pid="$(cat runtime/preview.pid)"
  if [[ -r "/proc/$preview_pid/cmdline" ]] && tr '\0' ' ' < "/proc/$preview_pid/cmdline" | grep -q 'node server.mjs'; then
    process_cwd="$(readlink "/proc/$preview_pid/cwd")"
    if [[ "$process_cwd" == "$PWD" ]]; then kill "$preview_pid"; fi
  fi
  rm runtime/preview.pid
fi
echo 'Stopped only this case preview process.'
