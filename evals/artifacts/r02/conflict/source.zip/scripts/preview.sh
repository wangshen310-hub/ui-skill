#!/usr/bin/env bash
set -euo pipefail
cd /opt/ui-skill-lab-20261020/round-0002-conflict
mkdir -p evidence runtime
export TMPDIR="$PWD/runtime"
export npm_config_cache="$PWD/runtime/npm-cache"
if ss -ltn | awk '{print $4}' | grep -q ':18863$'; then
  echo 'Port 18863 is already in use; no process was changed.' >&2
  exit 1
fi
node --check server.mjs
node --check src/conflict-dialog.js
node --check src/demo.js
npm run build
nohup node server.mjs > evidence/server.log 2>&1 &
echo "$!" > runtime/preview.pid
echo "Preview started with PID $(cat runtime/preview.pid), loopback port 18863."
