# 真实执行命令

控制端只编辑、复制与下载本案例产物；所有构建、浏览器运行、截图与文件操作验证在腾讯云完成。

读取指定技能、art-direction/writing/verification 与内置 imagegen 的 SKILL.md 后，调用 `tools.image_gen__imagegen`（prompt 为 `evidence/image-prompt.txt`、`transparent_background: false`），用 `generatedImage(result)` 展示并查看结果；再把工具自动保存的图复制到指定案例 `evidence/reference.png`。

```bash
ssh tencent-opencloudos 'if ss -ltn | awk '\''{print $4}'\'' | grep -q '\'':18863$'\''; then echo PORT_BUSY; else echo PORT_FREE; fi'
# 返回 PORT_FREE。

ssh tencent-opencloudos 'mkdir -p /opt/ui-skill-lab-20261020/round-0002-conflict'
scp -r /tmp/ui-skill-lab-20261020/round-0002-conflict/. tencent-opencloudos:/opt/ui-skill-lab-20261020/round-0002-conflict/
```

上传命令返回仍运行的 session 后，第一次 `node --check server.mjs`、`node --check src/conflict-dialog.js`、`node --check src/demo.js`、`npm run build` 提前执行，均报告文件未找到。等待传输 session 成功结束后，上传新增脚本并执行：

```bash
ssh tencent-opencloudos 'set -euo pipefail
cd /opt/ui-skill-lab-20261020/round-0002-conflict
bash scripts/preview.sh 2>&1 | tee evidence/build-original.log
TMPDIR="$PWD/runtime" /opt/social-auto-upload/.venv/bin/python scripts/browser-check.py --label original 2>&1 | tee evidence/browser-original.log'
```

`scripts/preview.sh` 包含 `ss` 端口检查、三个 `node --check`、`npm run build` 与 `nohup node server.mjs`，保存的 PID 仅属于本案例。Node 服务代码明确 `listen(18863, '127.0.0.1')`。

修正并单独上传 `src/conflict-dialog.js`、`src/styles.css`、`scripts/browser-check.py` 后：

```bash
ssh tencent-opencloudos 'set -euo pipefail
cd /opt/ui-skill-lab-20261020/round-0002-conflict
npm_config_cache="$PWD/runtime/npm-cache" npm run build 2>&1 | tee evidence/build-final.log
TMPDIR="$PWD/runtime" /opt/social-auto-upload/.venv/bin/python scripts/browser-check.py --label final 2>&1 | tee evidence/browser-final.log'
```

按明确文件名用 SSH `tar -czf - ... | tar -xzf - -C /tmp/ui-skill-lab-20261020/round-0002-conflict` 下载截图、结果 JSON、日志、远端 dist 和 fixtures；用本地图像查看工具实际查看所得截图。

最后：

```bash
ssh tencent-opencloudos 'set -euo pipefail
cd /opt/ui-skill-lab-20261020/round-0002-conflict
bash scripts/stop.sh
if ss -ltn | awk '\''{print $4}'\'' | grep -q '\'':18863$'\''; then echo PORT_STILL_IN_USE; exit 1; else echo PORT_FREE_AFTER_STOP; fi'
```

源文件哈希记录在 `evidence/source-sha256.txt`；停止结果在 `evidence/cleanup.log`。没有改变全局 npm registry、系统服务或其他项目。
