import http from 'node:http';
import { readFile, writeFile, mkdir, rm, readdir, stat, copyFile } from 'node:fs/promises';
import { constants } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';

const root = import.meta.dirname;
const fixtureRoot = path.join(root, 'fixtures');
const destination = path.join(fixtureRoot, '项目资料');
const incomingDir = path.join(fixtureRoot, '下载');
const fileName = '2026年秋季品牌发布会_场地与视觉执行方案_华东区域团队确认版_2026-10-20.md';
const existingPath = path.join(destination, fileName);
const incomingPath = path.join(incomingDir, fileName);
let resolving = false;
const existingText = '# 2026 秋季品牌发布会\n交付日期：10 月 23 日\n主视觉：石墨蓝\n会场：杭州 · 临江展厅\n备注：按首轮确认方案执行。\n';
const incomingText = '# 2026 秋季品牌发布会\n交付日期：10 月 25 日\n主视觉：苔绿色\n会场：杭州 · 临江展厅\n备注：使用场地方复核后的方案。\n';

async function reset() {
  await rm(fixtureRoot, { recursive: true, force: true });
  await mkdir(destination, { recursive: true });
  await mkdir(incomingDir, { recursive: true });
  await writeFile(existingPath, existingText);
  await writeFile(incomingPath, incomingText);
  const { utimes } = await import('node:fs/promises');
  await utimes(existingPath, new Date('2026-10-18T08:24:00Z'), new Date('2026-10-18T08:24:00Z'));
  await utimes(incomingPath, new Date('2026-10-20T02:08:00Z'), new Date('2026-10-20T02:08:00Z'));
}
async function describe(filePath) {
  const [data, info] = await Promise.all([readFile(filePath), stat(filePath)]);
  return {
    name: path.basename(filePath),
    path: '演示文件 / ' + path.relative(fixtureRoot, path.dirname(filePath)).split(path.sep).join(' / '),
    bytes: info.size,
    modified: info.mtime.toISOString(),
    hash: createHash('sha256').update(data).digest('hex'),
    text: data.toString('utf8')
  };
}
async function availableCopyName() {
  const names = await readdir(destination);
  const base = fileName.slice(0, -3);
  for (let i = 1; i < 10000; i++) {
    const name = `${base}（副本${i === 1 ? '' : i}）.md`;
    if (!names.includes(name)) return name;
  }
  throw new Error('没有可用的副本文件名。');
}
async function state() {
  const [existing, incoming, files, copyName] = await Promise.all([
    describe(existingPath), describe(incomingPath),
    readdir(destination).then(names => Promise.all(names.map(name => describe(path.join(destination, name))))),
    availableCopyName()
  ]);
  return { name: fileName, existing, incoming, files, copyName };
}
async function body(req) {
  let value = '';
  for await (const chunk of req) {
    value += chunk;
    if (value.length > 8192) throw new Error('请求过长。');
  }
  return JSON.parse(value || '{}');
}
function json(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}
await mkdir(root, { recursive: true });
try { await stat(existingPath); } catch { await reset(); }
const server = http.createServer(async (req, res) => {
  try {
    const route = new URL(req.url, 'http://127.0.0.1').pathname;
    if (req.method === 'GET' && route === '/api/state') return json(res, 200, await state());
    if (req.method === 'POST' && route === '/api/reset') {
      if (resolving) return json(res, 409, { error: '文件正在处理中，请稍后重置。' });
      await reset();
      return json(res, 200, await state());
    }
    if (req.method === 'POST' && route === '/api/resolve') {
      if (resolving) return json(res, 409, { error: '另一个操作正在处理，请稍后重试。' });
      resolving = true;
      try {
        const request = await body(req);
        if (!['keep', 'replace', 'skip'].includes(request.choice)) return json(res, 400, { error: '请选择一种处理方式。' });
        const current = await state();
        if (current.existing.hash !== request.existingHash || current.incoming.hash !== request.incomingHash) {
          return json(res, 409, { error: '文件已变化。请取消后重新打开，再比较文件。' });
        }
        let savedName = null;
        if (request.choice === 'keep') {
          if (request.copyName !== current.copyName) return json(res, 409, { error: '副本名称已被占用。请取消后重新打开。' });
          savedName = current.copyName;
          await copyFile(incomingPath, path.join(destination, savedName), constants.COPYFILE_EXCL);
        }
        if (request.choice === 'replace') {
          await copyFile(incomingPath, existingPath);
          savedName = fileName;
        }
        console.log(JSON.stringify({ at: new Date().toISOString(), choice: request.choice, savedName }));
        return json(res, 200, { choice: request.choice, savedName, state: await state() });
      } finally { resolving = false; }
    }
    if (req.method !== 'GET') return json(res, 405, { error: '不支持此请求。' });
    const allowed = { '/': 'index.html', '/index.html': 'index.html', '/styles.css': 'styles.css', '/conflict-dialog.js': 'conflict-dialog.js', '/demo.js': 'demo.js' };
    if (route === '/favicon.ico') { res.writeHead(204); return res.end(); }
    if (!allowed[route]) return json(res, 404, { error: '找不到这个页面。' });
    const content = await readFile(path.join(root, 'dist', allowed[route]));
    const type = route.endsWith('.css') ? 'text/css' : route.endsWith('.js') ? 'text/javascript' : 'text/html';
    res.writeHead(200, { 'Content-Type': `${type}; charset=utf-8`, 'Cache-Control': 'no-store' });
    res.end(content);
  } catch (error) {
    console.error(error.message);
    json(res, 500, { error: '无法读写演示文件，请检查预览服务后重试。' });
  }
});
server.listen(18863, '127.0.0.1', () => console.log('File conflict demo: http://127.0.0.1:18863'));
