import { formatBytes, formatDate } from './conflict-dialog.js';

const copy = document.querySelector('#copy');
const reset = document.querySelector('#reset');
const status = document.querySelector('#status');
const dialog = document.querySelector('file-conflict-dialog');
async function request(url, data) {
  const response = await fetch(url, data ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) } : {});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || '演示文件服务没有响应，请重试。');
  return result;
}
function render(state) {
  document.querySelector('#files').replaceChildren(...state.files.map(file => {
    const row = document.createElement('div');
    row.className = 'file-row';
    for (const value of [file.name, formatBytes(file.bytes), formatDate(file.modified)]) {
      const cell = document.createElement('span');
      cell.textContent = value;
      row.append(cell);
    }
    return row;
  }));
}
async function open() {
  copy.disabled = true;
  try {
    const state = await request('/api/state');
    copy.disabled = false;
    copy.focus();
    const result = await dialog.showConflict(state, async (choice, details) => request('/api/resolve', {
      choice, existingHash: details.existing.hash, incomingHash: details.incoming.hash, copyName: details.copyName
    }));
    if (result.choice === 'cancel') status.textContent = '已取消复制，文件未改动。';
    else {
      render(result.state);
      status.textContent = result.choice === 'keep' ? `已保留两者，副本已写入「项目资料」：${result.savedName}` : result.choice === 'replace' ? '已用传入文件替换「项目资料」中的同名文件。' : '已跳过此文件，现有文件未改动。';
    }
  } catch (error) { status.textContent = error.message; }
  finally { copy.disabled = false; }
}
copy.addEventListener('click', open);
reset.addEventListener('click', async () => {
  reset.disabled = true;
  copy.disabled = true;
  try { render(await request('/api/reset', {})); status.textContent = '已重置独立的演示文件，可以再次复制。'; }
  catch (error) { status.textContent = error.message; }
  finally { reset.disabled = false; copy.disabled = false; }
});
try { render(await request('/api/state')); status.textContent = '1 个演示文件。'; }
catch (error) { status.textContent = error.message; copy.disabled = true; }
