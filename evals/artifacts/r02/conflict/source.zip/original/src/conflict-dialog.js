const documentIcon = `<svg aria-hidden="true" viewBox="0 0 32 38"><path d="M6 2h13l8 8v26H6z"/><path d="M19 2v9h8M11 17h11M11 23h11M11 29h8"/></svg>`;
export const formatBytes = bytes => `${bytes.toLocaleString('zh-CN')} 字节`;
export const formatDate = value => new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(value)).replaceAll('/', '-');

/** Embeddable light-DOM web component. Import styles.css in the host. */
export class FileConflictDialog extends HTMLElement {
  constructor() {
    super();
    this.innerHTML = `<dialog class="conflict" aria-labelledby="conflict-title" aria-describedby="conflict-context conflict-warning">
      <div class="dialog-top"><div class="title-group"><span class="conflict-icon">${documentIcon}<span aria-hidden="true">!</span></span><h1 id="conflict-title">同名文件已存在</h1></div><button class="icon-button close" type="button" aria-label="取消复制"><svg aria-hidden="true" viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg></button></div>
      <div class="file-context"><p class="full-name" id="conflict-name"></p><p class="context" id="conflict-context">复制到「项目资料」时发现同名文件。</p></div>
      <div class="comparisons"><section class="comparison existing" aria-labelledby="existing-title"><h2 id="existing-title">现有文件</h2><div class="file-origin">${documentIcon}<div><span class="file-kind">Markdown 文档</span><p class="directory" data-side="existing"></p></div></div><dl><div><dt>修改时间</dt><dd data-field="existing-modified"></dd></div><div><dt>大小</dt><dd data-field="existing-size"></dd></div></dl><h3>文本预览 · 全文</h3><div class="text-preview" data-preview="existing"></div></section>
      <section class="comparison incoming" aria-labelledby="incoming-title"><h2 id="incoming-title">传入文件 <span class="newer-badge">较新</span></h2><div class="file-origin">${documentIcon}<div><span class="file-kind">Markdown 文档</span><p class="directory" data-side="incoming"></p></div></div><dl><div><dt>修改时间</dt><dd data-field="incoming-modified"></dd></div><div><dt>大小</dt><dd data-field="incoming-size"></dd></div></dl><h3>文本预览 · 全文</h3><div class="text-preview" data-preview="incoming"></div></section></div>
      <div class="rename-preview"><span>保留两者时，传入文件将重命名为</span><p id="copy-name"></p></div>
      <p id="conflict-warning" class="warning">替换会覆盖现有文件，无法撤销。</p>
      <p class="dialog-error" id="conflict-error" role="alert" hidden></p>
      <footer class="dialog-actions"><button type="button" data-choice="skip" class="subtle skip">跳过</button><div><button type="button" data-choice="replace" class="replace">替换</button><button type="button" data-choice="keep" class="primary keep">保留两者</button></div></footer>
    </dialog>`;
    this.dialog = this.querySelector('dialog');
    this.error = this.querySelector('.dialog-error');
    this.pending = false;
    this.querySelector('.close').addEventListener('click', () => this.cancel());
    this.dialog.addEventListener('cancel', event => { event.preventDefault(); this.cancel(); });
    for (const button of this.querySelectorAll('[data-choice]')) button.addEventListener('click', () => this.attempt(button.dataset.choice));
    this.dialog.addEventListener('keydown', event => {
      if (event.key !== 'Tab' || this.pending) return;
      const buttons = [...this.querySelectorAll('button:not(:disabled)')];
      if (event.shiftKey && document.activeElement === buttons[0]) { event.preventDefault(); buttons.at(-1).focus(); }
      if (!event.shiftKey && document.activeElement === buttons.at(-1)) { event.preventDefault(); buttons[0].focus(); }
    });
  }
  showConflict(details, resolveAction) {
    if (this.dialog.open) throw new Error('冲突窗口已打开。');
    this.details = details;
    this.resolveAction = resolveAction;
    this.returnFocus = document.activeElement;
    this.error.hidden = true;
    this.querySelector('#conflict-name').textContent = details.name;
    this.querySelector('#copy-name').textContent = details.copyName;
    this.querySelector('.newer-badge').hidden = new Date(details.incoming.modified) <= new Date(details.existing.modified);
    for (const side of ['existing', 'incoming']) {
      const file = details[side];
      this.querySelector(`[data-side="${side}"]`).textContent = file.path;
      this.querySelector(`[data-field="${side}-modified"]`).textContent = `${formatDate(file.modified)}（北京时间）`;
      this.querySelector(`[data-field="${side}-size"]`).textContent = formatBytes(file.bytes);
      this.preview(side, file.text, details[side === 'existing' ? 'incoming' : 'existing'].text);
    }
    this.dialog.showModal();
    this.querySelector('[data-choice="keep"]').focus({ preventScroll: true });
    this.dialog.scrollTop = 0;
    return new Promise(resolve => { this.finish = resolve; });
  }
  preview(side, text, other) {
    const target = this.querySelector(`[data-preview="${side}"]`);
    target.replaceChildren();
    const lines = text.trimEnd().split('\n');
    const others = other.trimEnd().split('\n');
    lines.forEach((line, index) => {
      const paragraph = document.createElement('p');
      if (line !== others[index]) {
        const mark = document.createElement('mark');
        mark.textContent = line;
        paragraph.append(mark);
        const hint = document.createElement('span');
        hint.className = 'sr-only';
        hint.textContent = '（内容不同）';
        paragraph.append(hint);
      } else paragraph.textContent = line;
      target.append(paragraph);
    });
  }
  cancel() {
    if (this.pending) return;
    this.close({ choice: 'cancel' });
  }
  close(result) {
    this.dialog.close();
    if (this.returnFocus?.isConnected) this.returnFocus.focus({ preventScroll: true });
    this.finish?.(result);
    this.finish = null;
  }
  async attempt(choice) {
    if (this.pending) return;
    this.pending = true;
    this.error.hidden = true;
    this.dialog.setAttribute('aria-busy', 'true');
    const buttons = [...this.querySelectorAll('button')];
    const selected = this.querySelector(`[data-choice="${choice}"]`);
    const original = selected.textContent;
    selected.textContent = choice === 'skip' ? '正在跳过…' : choice === 'replace' ? '正在替换…' : '正在保留…';
    buttons.forEach(button => button.disabled = true);
    try {
      const result = await this.resolveAction(choice, this.details);
      this.pending = false;
      this.close({ choice, ...result });
    } catch (error) {
      this.error.textContent = error.message || '未能完成操作，请重试。';
      this.error.hidden = false;
    } finally {
      this.pending = false;
      selected.textContent = original;
      buttons.forEach(button => button.disabled = false);
      this.dialog.removeAttribute('aria-busy');
      if (this.dialog.open) selected.focus();
    }
  }
}
customElements.define('file-conflict-dialog', FileConflictDialog);
