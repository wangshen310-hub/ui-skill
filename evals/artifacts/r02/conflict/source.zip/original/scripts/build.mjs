import { cp, mkdir, readdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
await mkdir(path.join(root, 'dist'), { recursive: true });
await cp(path.join(root, 'src'), path.join(root, 'dist'), { recursive: true });
const manifest = {};
for (const name of await readdir(path.join(root, 'dist'))) {
  if (name === 'manifest.json') continue;
  manifest[name] = createHash('sha256').update(await readFile(path.join(root, 'dist', name))).digest('hex');
}
await writeFile(path.join(root, 'dist/manifest.json'), JSON.stringify(manifest, null, 2));
console.log('Built static component and demo host:', Object.keys(manifest).join(', '));
