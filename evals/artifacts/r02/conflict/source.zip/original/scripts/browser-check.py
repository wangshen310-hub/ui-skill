import argparse
import hashlib
import json
import os
from pathlib import Path
from patchright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--label', default='original')
args = parser.parse_args()
ROOT = Path('/opt/ui-skill-lab-20261020/round-0002-conflict')
EVIDENCE = ROOT / 'evidence'
EVIDENCE.mkdir(exist_ok=True)
RUNTIME = ROOT / 'runtime'
RUNTIME.mkdir(exist_ok=True)
os.environ['TMPDIR'] = str(RUNTIME)
URL = 'http://127.0.0.1:18863'
checks = []
errors = []

def check(name, condition, details=None):
    item = {'check': name, 'passed': bool(condition)}
    if details is not None: item['details'] = details
    checks.append(item)
    print(json.dumps(item, ensure_ascii=False), flush=True)

def disk_state():
    result = {}
    for folder in ['项目资料', '下载']:
        result[folder] = {}
        for file in sorted((ROOT / 'fixtures' / folder).glob('*')):
            result[folder][file.name] = {'bytes': file.stat().st_size, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest(), 'text': file.read_text()}
    return result

with sync_playwright() as p:
    context = p.chromium.launch_persistent_context(
        str(RUNTIME / f'browser-profile-{args.label}'), executable_path='/usr/bin/google-chrome',
        headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'],
        viewport={'width': 1440, 'height': 1000}, device_scale_factor=1, locale='zh-CN',
        reduced_motion='reduce'
    )
    page = context.pages[0]
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.on('console', lambda message: errors.append(message.text) if message.type == 'error' else None)

    def fresh():
        response = page.request.post(URL + '/api/reset', data={})
        assert response.ok
        page.goto(URL)
        page.get_by_role('button', name='复制文件…', exact=True).wait_for()
        page.get_by_role('button', name='复制文件…', exact=True).click()
        page.get_by_role('dialog').wait_for()

    def active(): return page.evaluate('document.activeElement.outerHTML')
    def snapshot(): return page.request.get(URL + '/api/state').json()

    fresh()
    initial = snapshot()
    before = disk_state()
    check('initial full filename matches actual fixture', page.locator('#conflict-name').inner_text() == initial['name'])
    check('comparison metadata comes from disk', page.locator('[data-field="existing-size"]').inner_text() == f"{initial['existing']['bytes']} 字节" and page.locator('[data-field="incoming-size"]').inner_text() == f"{initial['incoming']['bytes']} 字节")
    check('both full text previews are visible and reflect disk', page.locator('[data-preview="existing"]').inner_text().replace('（内容不同）', '').strip() == initial['existing']['text'].strip() and page.locator('[data-preview="incoming"]').inner_text().replace('（内容不同）', '').strip() == initial['incoming']['text'].strip())
    check('safe initial focus on keep both', page.locator('[data-choice="keep"]').evaluate('(e)=>e===document.activeElement'), active())
    page.screenshot(path=str(EVIDENCE / f'{args.label}-desktop.png'), full_page=True)
    desktop_layout = page.evaluate('''() => {const d=document.querySelector('dialog'); const n=document.querySelector('#conflict-name');const b=n.getBoundingClientRect();return {viewport:[innerWidth,innerHeight], dialog:{x:d.offsetLeft,y:d.offsetTop,width:d.offsetWidth,height:d.offsetHeight,scrollHeight:d.scrollHeight,clientHeight:d.clientHeight}, pageOverflow:document.documentElement.scrollWidth>innerWidth, nameOverflow:n.scrollWidth>n.clientWidth, nameBox:{width:b.width,height:b.height}, nameStyle:{textOverflow:getComputedStyle(n).textOverflow,whiteSpace:getComputedStyle(n).whiteSpace}}}''')
    check('desktop dialog and filename fit', not desktop_layout['pageOverflow'] and not desktop_layout['nameOverflow'] and desktop_layout['dialog']['height'] <= 1000, desktop_layout)
    page.keyboard.press('Tab')
    check('Tab wraps within dialog', page.get_by_role('button', name='取消复制').evaluate('(e)=>e===document.activeElement'), active())
    page.keyboard.press('Shift+Tab')
    check('Shift+Tab wraps within dialog', page.locator('[data-choice="keep"]').evaluate('(e)=>e===document.activeElement'), active())
    page.keyboard.press('Escape')
    check('Escape closes and restores trigger focus', not page.get_by_role('dialog').is_visible() and page.locator('#copy').evaluate('(e)=>e===document.activeElement'))
    check('cancel does not modify fixture bytes', disk_state() == before)
    page.locator('#copy').press('Enter')
    page.get_by_role('button', name='取消复制').click()
    check('close control cancels without disk changes', not page.get_by_role('dialog').is_visible() and disk_state() == before)

    # Keep-both via keyboard; verify actual content and filename on disk.
    page.locator('#copy').press('Enter')
    page.locator('[data-choice="keep"]').press('Enter')
    page.get_by_role('dialog').wait_for(state='hidden')
    after_keep = disk_state()
    original_name = initial['name']
    copy_name = initial['copyName']
    check('keep both writes exactly one expected copy', set(after_keep['项目资料']) == {original_name, copy_name})
    check('keep both preserves original content', after_keep['项目资料'][original_name] == before['项目资料'][original_name])
    check('new copy bytes equal incoming bytes', after_keep['项目资料'][copy_name] == before['下载'][original_name])
    check('keep result restores trigger focus', page.locator('#copy').evaluate('(e)=>e===document.activeElement'))
    page.screenshot(path=str(EVIDENCE / f'{args.label}-keep-result.png'), full_page=True)
    (EVIDENCE / f'{args.label}-disk-after-keep.json').write_text(json.dumps(after_keep, ensure_ascii=False, indent=2))

    # A second real copy proves the preview name and actual name agree on collision.
    page.locator('#copy').click()
    second_state = snapshot()
    check('existing copy advances copy name', '（副本2）.md' in page.locator('#copy-name').inner_text())
    page.locator('[data-choice="keep"]').click()
    page.get_by_role('dialog').wait_for(state='hidden')
    second = disk_state()
    check('second keep uses previewed unique name', second_state['copyName'] in second['项目资料'] and len(second['项目资料']) == 3)

    # Replace via Space, with exact disk content check.
    fresh()
    replace_before = disk_state()
    page.locator('[data-choice="replace"]').press('Space')
    page.get_by_role('dialog').wait_for(state='hidden')
    replaced = disk_state()
    check('replace writes incoming bytes under original name', len(replaced['项目资料']) == 1 and replaced['项目资料'][original_name] == replace_before['下载'][original_name])
    check('replace leaves source file intact', replaced['下载'] == replace_before['下载'])

    # Skip and failure/retry.
    fresh()
    skip_before = disk_state()
    page.locator('[data-choice="skip"]').click()
    page.get_by_role('dialog').wait_for(state='hidden')
    check('skip leaves both directories unchanged', disk_state() == skip_before)
    fresh()
    error_before = disk_state()
    page.route('**/api/resolve', lambda route: route.fulfill(status=500, content_type='application/json', body=json.dumps({'error':'演示：暂时无法写入，请重试。'}, ensure_ascii=False)), times=1)
    page.locator('[data-choice="keep"]').click()
    page.locator('#conflict-error').wait_for(state='visible')
    check('failed request retains dialog and shows error', page.get_by_role('dialog').is_visible() and '暂时无法写入' in page.locator('#conflict-error').inner_text())
    check('failed request leaves disk unchanged and permits retry', disk_state() == error_before and page.locator('[data-choice="keep"]').is_enabled())
    page.screenshot(path=str(EVIDENCE / f'{args.label}-error.png'), full_page=True)
    page.locator('[data-choice="keep"]').click()
    page.get_by_role('dialog').wait_for(state='hidden')
    check('retry performs real copy', len(disk_state()['项目资料']) == 2)

    # Narrow view and low height: actual scroll and focus visibility are recorded.
    page.set_viewport_size({'width':390, 'height':844})
    fresh()
    page.screenshot(path=str(EVIDENCE / f'{args.label}-narrow-top.png'), full_page=True)
    narrow = page.evaluate('''()=>{const d=document.querySelector('dialog'),a=document.activeElement,b=a.getBoundingClientRect(),r=d.getBoundingClientRect();return {pageOverflow:document.documentElement.scrollWidth>innerWidth,dialogOverflow:d.scrollWidth>d.clientWidth,dialogHeight:r.height,viewportHeight:innerHeight,scrollTop:d.scrollTop,scrollHeight:d.scrollHeight,clientHeight:d.clientHeight,active:a.outerHTML,activeVisible:b.top>=r.top&&b.bottom<=r.bottom,nameOverflow:document.querySelector('#conflict-name').scrollWidth>document.querySelector('#conflict-name').clientWidth}}''')
    check('narrow width has no horizontal clipping', not narrow['pageOverflow'] and not narrow['dialogOverflow'] and not narrow['nameOverflow'], narrow)
    check('narrow initial focused element is visible', narrow['activeVisible'])
    page.locator('[data-choice="keep"]').scroll_into_view_if_needed()
    page.screenshot(path=str(EVIDENCE / f'{args.label}-narrow-bottom.png'), full_page=True)
    page.locator('[data-choice="skip"]').click()
    page.get_by_role('dialog').wait_for(state='hidden')
    check('narrow action reachable and completes', '已跳过' in page.locator('#status').inner_text())
    page.set_viewport_size({'width':1024, 'height':600})
    fresh()
    low = page.evaluate('''()=>{const d=document.querySelector('dialog'),a=document.activeElement,b=a.getBoundingClientRect(),r=d.getBoundingClientRect();return {height:r.height,viewportHeight:innerHeight,scrollHeight:d.scrollHeight,clientHeight:d.clientHeight,activeVisible:b.top>=r.top&&b.bottom<=r.bottom}}''')
    check('low-height content remains scrollable inside viewport', low['height'] <= low['viewportHeight'] and low['scrollHeight'] >= low['clientHeight'], low)
    page.locator('[data-choice="keep"]').scroll_into_view_if_needed()
    page.screenshot(path=str(EVIDENCE / f'{args.label}-low-height.png'), full_page=True)
    page.keyboard.press('Escape')
    check('low-height Escape restores focus', page.locator('#copy').evaluate('(e)=>e===document.activeElement'))
    check('browser has no uncaught JavaScript errors', not errors, errors)
    # Leave a deliberate, reproducible real file outcome: the keep-both copy.
    page.set_viewport_size({'width':1440, 'height':1000})
    fresh()
    page.locator('[data-choice="keep"]').click()
    page.get_by_role('dialog').wait_for(state='hidden')
    final_disk = disk_state()
    (EVIDENCE / f'{args.label}-final-disk.json').write_text(json.dumps(final_disk, ensure_ascii=False, indent=2))
    context.close()

result = {'label':args.label,'browser':'Google Chrome / Patchright on tencent-opencloudos','checks':checks,'browserErrors':errors,'passed':sum(item['passed'] for item in checks),'total':len(checks)}
(EVIDENCE / f'{args.label}-results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps({'passed':result['passed'],'total':result['total']}, ensure_ascii=False))
