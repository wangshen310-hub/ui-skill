# 底片 · 批量导出（评审修订源码）

本修订修复跨目录重复导出时累计历史完成数量的问题。完成提示只统计本次任务并给出实际目录；原队列状态和已有输出路径保留。“移除”按钮改为“移除此行”。没有重做布局。本修订是案例代码修复，不证明设计技能本身已改进。

这是源码包，不携带Python、Qt库、系统动态库、venv、截图或测试图片。依赖版本在 `requirements.txt`。

在具备Qt/X11系统动态库与中文字体的Linux环境建立隔离虚拟环境：

```sh
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

在X11桌面会话运行 `./run.sh`，打开明确标注的绘制样例；`./run.sh --empty` 打开空队列。若目标环境缺少Qt/xcb动态库，需要该环境自行提供。此次腾讯云验证复用原案例隔离的 `native-deps/root/usr/lib64`，源码包不包含这类依赖。

针对本修复的原生X11测试：

```sh
.venv/bin/python src/run_review_x11.py src/verify_review_fix.py
```

需要已有的Xvfb、xdotool及Qt/xcb库。测试只在当前案例副本下的 `evidence/review-fix/` 生成绘制样例、实际JPEG、JSON和原生截图。为保留证据，`verification-data` 已存在时会拒绝覆盖；再次运行应使用新的隔离源码副本。

所有修前/修后证据保留在原远端案例目录 `evidence/review-fix/`，旧归档、旧报告和初始截图保持原样。截图仍是实际xcb窗口，Xvfb没有窗口管理器，未验证系统模态焦点恢复。未验证Windows/macOS、Wayland或真实业务。
