"""Private low-resource Xvfb runner; review evidence is appended only in its new folder."""
from pathlib import Path
import os, select, subprocess, sys
BASE=Path(__file__).resolve().parents[1]
EVIDENCE=BASE/"evidence/review-fix"
EVIDENCE.mkdir(parents=True,exist_ok=True)
read_fd,write_fd=os.pipe()
with (EVIDENCE/"xvfb-review.log").open("a") as log:
    display_process=subprocess.Popen(["Xvfb","-displayfd",str(write_fd),"-screen","0","1280x900x24","-nolisten","tcp"],pass_fds=(write_fd,),stdout=log,stderr=log)
    os.close(write_fd)
    try:
        if not select.select([read_fd],[],[],10)[0]: raise RuntimeError("Xvfb did not allocate a display")
        display=os.read(read_fd,32).decode().strip()
        if not display.isdigit(): raise RuntimeError("Xvfb failed: "+display)
        env=os.environ.copy()
        env["DISPLAY"]=":"+display
        env["QT_QPA_PLATFORM"]="xcb"
        env["LD_LIBRARY_PATH"]=str(BASE/"native-deps/root/usr/lib64")+(":"+env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
        runtime=EVIDENCE/"runtime"
        runtime.mkdir(exist_ok=True,mode=0o700)
        env["XDG_RUNTIME_DIR"]=str(runtime)
        print("X11 DISPLAY="+env["DISPLAY"]+" QT_QPA_PLATFORM=xcb; private Xvfb PID="+str(display_process.pid),flush=True)
        result=subprocess.run([sys.executable]+sys.argv[1:],cwd=BASE,env=env)
    finally:
        os.close(read_fd)
        display_process.terminate()
        try: display_process.wait(timeout=5)
        except subprocess.TimeoutExpired: display_process.kill();display_process.wait()
        print("Private Xvfb stopped; returncode="+str(display_process.returncode),flush=True)
sys.exit(result.returncode)
