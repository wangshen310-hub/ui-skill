"""Targeted real-export regression checks for the independently reproduced review findings."""
from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
from PIL import Image
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from app import make_application,QueueWindow
from fixtures import BASE,paint
EVIDENCE=BASE/"evidence/review-fix"
ROOT=EVIDENCE/"verification-data"
ROOT.mkdir(exist_ok=False)
inputs=ROOT/"inputs";inputs.mkdir()
names=["林间婚礼_精选_001.jpg","林间婚礼_精选_002.jpg","城市建筑外景_秋季作品集_交付客户最终确认版本_001.jpg","山间湖泊_日出_004.jpg"]
paths=[]
for index,name in enumerate(names):
    path=inputs/name
    paint(path,index if index<3 else 4)
    paths.append(path)
A=ROOT/"A";A.mkdir()
B=ROOT/"B";B.mkdir()
C=ROOT/"C";C.mkdir()
app=make_application()
assert app.platformName()=="xcb"
window=QueueWindow(demo=True)
window.add_files(paths)
window.show();window.activateWindow()
subprocess.run(["xdotool","windowfocus","--sync",str(int(window.winId()))],check=True)
QTest.qWait(120)
checks=[]

def wait():
    deadline=time.monotonic()+30
    while (window.running() or window.progress.isVisible()) and time.monotonic()<deadline:QTest.qWait(20)
    QTest.qWait(100)
    assert not window.running() and not window.progress.isVisible()

def outputs(directory):
    result=[]
    for path in sorted(directory.iterdir()):
        if path.name.startswith("."):continue
        with Image.open(path) as image:
            image.load()
            assert image.format=="JPEG" and image.size==(1600,1000)
            result.append({"path":str(path),"format":image.format,"dimensions":list(image.size),"bytes":path.stat().st_size,"sha256":hashlib.sha256(path.read_bytes()).hexdigest()})
    return result

def shot(name):
    QTest.qWait(100)
    assert window.screen().grabWindow(window.winId()).save(str(EVIDENCE/name))

def record(name,**evidence):
    result={"check":name,"result":"passed",**evidence}
    checks.append(result)
    print(json.dumps(result,ensure_ascii=False),flush=True)

def state():
    return [{"name":e.path.name,"state":e.state,"output":e.output,"detail":e.detail} for e in window.entries]

def pick(rows):
    window.toggle_all(False)
    for row in rows:window.table.item(row,0).setCheckState(Qt.CheckState.Checked)

try:
    window.directory.setText(str(A))
    QTest.mouseClick(window.export_button,Qt.MouseButton.LeftButton)
    wait()
    first=outputs(A)
    assert len(first)==4 and window.feedback.text()==f"本次已导出 4 张。输出目录：{A}"
    assert len(window.batch_results)==4
    shot("after-fix-A-four-exported.png")
    record("whole batch A reports only this batch and exact directory",files=first,feedback=window.feedback.text(),queue=state())

    pick([0]);window.directory.setText(str(B))
    QTest.mouseClick(window.export_button,Qt.MouseButton.LeftButton);wait()
    second=outputs(B)
    assert len(second)==1
    assert window.feedback.text()==f"本次已导出 1 张。输出目录：{B}"
    assert len(window.batch_results)==1 and all(e.state=="done" for e in window.entries)
    assert all(Path(e.output).parent==A for e in window.entries[1:])
    assert outputs(A)==first
    shot("after-fix-B-one-exported.png")
    record("A history does not inflate one-image export to B; historical row paths remain A",files=second,feedback=window.feedback.text(),queue=state(),A_files_unchanged=True)

    # An actual corrupt input fails while the other queue rows remain historical successes.
    broken=inputs/"修复重试_样例图片.jpg"
    broken.write_bytes(b"Deliberately corrupt JPEG for review regression test.\n")
    window.add_files([broken])
    pick([4]);window.directory.setText(str(C))
    QTest.keyClick(window,Qt.Key.Key_Return,Qt.KeyboardModifier.ControlModifier);wait()
    assert not outputs(C)
    assert window.feedback.text()==f"本次已导出 0 张；1 张失败，修复文件或目录后可重试。输出目录：{C}"
    assert window.entries[4].state=="failed" and all(e.state=="done" for e in window.entries[:4])
    assert len(window.batch_results)==1 and window.retry_button.isEnabled()
    window.table.setCurrentCell(4,2)
    shot("after-fix-C-failed-one.png")
    record("one actual corrupt source reports zero current successes and one failure despite four historical done rows",feedback=window.feedback.text(),queue=state())

    # A success from another selected row must not report an unrelated old failed row.
    pick([1]);window.directory.setText(str(B))
    QTest.mouseClick(window.export_button,Qt.MouseButton.LeftButton);wait()
    assert len(outputs(B))==2
    assert window.feedback.text()==f"本次已导出 1 张。输出目录：{B}"
    assert window.entries[4].state=="failed" and window.retry_button.isEnabled()
    shot("after-fix-B-success-with-old-failure.png")
    record("unrelated historical failure remains in queue but is not counted in successful current batch",feedback=window.feedback.text(),queue=state())

    # Repair the source and use the retry shortcut while the checkbox selects another row.
    paint(broken,3)
    beforeB=outputs(B);beforeA=outputs(A)
    window.directory.setText(str(C))
    QTest.keyClick(window,Qt.Key.Key_R,Qt.KeyboardModifier.ControlModifier);wait()
    repaired=outputs(C)
    assert len(repaired)==1
    assert window.feedback.text()==f"本次已导出 1 张。输出目录：{C}"
    assert len(window.batch_results)==1 and all(e.state=="done" for e in window.entries)
    assert not window.retry_button.isEnabled()
    assert outputs(B)==beforeB and outputs(A)==beforeA
    assert Path(window.entries[4].output).parent==C
    shot("after-fix-C-retry-success.png")
    record("Ctrl+R retries only the repaired failed item; reports one current output to C; previous output hashes unchanged",files=repaired,feedback=window.feedback.text(),queue=state())

    # Make the label explicit without changing the established current-row behavior.
    window.toggle_all(True);window.table.setCurrentCell(1,2)
    assert window.remove_button.text()=="移除此行"
    checked_before=len(window.selected_rows());before=[e.path.name for e in window.entries]
    current=window.entries[1].path.name
    shot("after-fix-remove-label.png")
    QTest.mouseClick(window.remove_button,Qt.MouseButton.LeftButton)
    after=[e.path.name for e in window.entries]
    assert checked_before==5 and len(after)==4 and current not in after
    assert [name for name in before if name not in after]==[current]
    assert all(path.exists() for path in paths) and broken.exists()
    shot("after-fix-remove-one-row.png")
    record("explicit remove-current-row label matches action while five rows are checked",button_text=window.remove_button.text(),checked_before=checked_before,removed=[current],retained=after,source_files_preserved=True)

    window.resize(680,500);QTest.qWait(120)
    for control in [window.export_button,window.directory_button,window.remove_button,window.format,window.quality]:
        assert control.isVisible() and window.rect().contains(control.geometry())
    assert window.sample_label.isVisible()
    shot("after-fix-minimum-680x500.png")
    record("updated label and directory-specific feedback leave main controls reachable at 680x500")
    report={"status":"passed","checks":checks,"app_sha256":hashlib.sha256((BASE/"src/app.py").read_bytes()).hexdigest(),"qpa":app.platformName(),"display":os.environ["DISPLAY"],"window_exposed":window.windowHandle().isExposed(),"real_outputs":{"A":outputs(A),"B":outputs(B),"C":outputs(C)},"scope":"case code repair; this does not prove a skill improvement","limits":["No window manager; application focus explicitly activated for shortcut tests.","Not a repeat of the original entire platform matrix; only listed regressions exercised."]}
except Exception:
    report={"status":"failed","checks":checks,"exception":traceback.format_exc()}
    print(report["exception"],flush=True)
    shot("review-fix-test-failure.png")
finally:
    window.close();app.processEvents()
    (EVIDENCE/"after-fix-results.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
if report["status"]!="passed":raise SystemExit(1)
