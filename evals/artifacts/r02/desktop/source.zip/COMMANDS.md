# 实际执行的主要命令与工具

所有下面的 Python、依赖和 X11 命令实际通过 SSH 在腾讯云执行。源码从控制端 `/tmp/ui-skill-lab-20261020/round-0002-desktop/src/` 用 scp 传入。完整 stdout/stderr 已保留在 `evidence/*.log`；初始和失败尝试保留独立文件。

```sh
ssh -o BatchMode=yes tencent-opencloudos 'uname -a; command -v python3.11; command -v Xvfb; command -v xdotool; command -v import; fc-list :lang=zh family | head -5'
```

远端隔离环境安装实际命令：

```sh
python3.11 -m venv /opt/ui-skill-lab-20261020/round-0002-desktop/.venv
/opt/ui-skill-lab-20261020/round-0002-desktop/.venv/bin/pip install --disable-pip-version-check PySide6-Essentials Pillow
```

首次 xcb 失败后，实际诊断和隔离修复命令：

```sh
ldd /opt/ui-skill-lab-20261020/round-0002-desktop/.venv/lib/python3.11/site-packages/PySide6/Qt/plugins/platforms/libqxcb.so | grep 'not found'
cd /opt/ui-skill-lab-20261020/round-0002-desktop
mkdir -p native-deps/rpms native-deps/root native-deps/cache native-deps/log native-deps/persist
dnf --setopt=cachedir=$PWD/native-deps/cache --setopt=logdir=$PWD/native-deps/log --setopt=persistdir=$PWD/native-deps/persist download --destdir=$PWD/native-deps/rpms xcb-util-cursor
cd native-deps/root
rpm2cpio ../rpms/xcb-util-cursor-0.1.4-3.oc9.x86_64.rpm | cpio -idmu
```

构建/工程检查是 Python 字节码编译检查，没有虚构二进制构建：

```sh
cd /opt/ui-skill-lab-20261020/round-0002-desktop
.venv/bin/python -m compileall -q src
.venv/bin/python src/headless_runner.py src/capture_initial.py
.venv/bin/python src/headless_runner.py src/test_workflow.py
.venv/bin/python src/headless_runner.py src/capture_scale.py
QT_SCALE_FACTOR=1.5 .venv/bin/python src/headless_runner.py src/capture_scale.py
.venv/bin/python src/headless_runner.py src/verify_launcher.py
.venv/bin/pip freeze > requirements.txt
sha256sum src/*.py > evidence/source-sha256.txt
```

`headless_runner.py` 实际启动的原生命令是 `Xvfb -displayfd <本进程管道FD> -screen 0 1600x1100x24 -nolisten tcp`，设置进程级 `QT_QPA_PLATFORM=xcb`、隔离的 `XDG_RUNTIME_DIR` 和本地解包库路径，再执行指定 Python 脚本。没有 offscreen 回退。

图像生成调用：内置 `image_gen.imagegen`，一张新图，`transparent_background=false`，没有参考图输入，也没有CLI或外部API调用。完整提示词见 `evidence/imagegen-prompt.txt`。调用结果使用 `generatedImage(result)` 展示并实际查看。最终对照所用原生截图下载后用 `view_image` 实际查看；没有用截图路径的存在代替视觉查看。

依赖解析用了现有的腾讯云 PyPI 镜像与现有 dnf 仓库；没有更改全局配置。所有下载缓存与解包文件均在本例远端目录。
