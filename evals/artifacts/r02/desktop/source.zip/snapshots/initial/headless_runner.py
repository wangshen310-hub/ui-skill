"""Run a real X11/xcb Qt process on a private Xvfb; no offscreen fallback."""
from pathlib import Path
import os, select, subprocess, sys
BASE=Path(__file__).resolve().parents[1]
(BASE/"evidence").mkdir(exist_ok=True)
read_fd,write_fd=os.pipe()
with (BASE/"evidence/xvfb.log").open("a") as log:
    xvfb=subprocess.Popen(["Xvfb","-displayfd",str(write_fd),"-screen","0","1600x1100x24","-nolisten","tcp"],pass_fds=(write_fd,),stdout=log,stderr=log)
    os.close(write_fd)
    try:
        if not select.select([read_fd],[],[],10)[0]: raise RuntimeError("Xvfb did not allocate a display")
        display=os.read(read_fd,32).decode().strip()
        if not display.isdigit(): raise RuntimeError("Xvfb failed: "+display)
        env=os.environ.copy()
        env["DISPLAY"]=":"+display
        env["QT_QPA_PLATFORM"]="xcb"
        env["LD_LIBRARY_PATH"]=str(BASE/"native-deps/root/usr/lib64") + (":"+env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
        runtime=BASE/"runtime"
        runtime.mkdir(exist_ok=True,mode=0o700)
        env["XDG_RUNTIME_DIR"]=str(runtime)
        print("X11 DISPLAY="+env["DISPLAY"]+" QT_QPA_PLATFORM=xcb",flush=True)
        result=subprocess.run([sys.executable]+sys.argv[1:],cwd=BASE,env=env)
        sys.exit(result.returncode)
    finally:
        os.close(read_fd)
        xvfb.terminate()
        try: xvfb.wait(timeout=5)
        except subprocess.TimeoutExpired: xvfb.kill()
