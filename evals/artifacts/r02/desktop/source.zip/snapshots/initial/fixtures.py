"""Clearly synthetic local sample inputs, including one deliberately corrupt JPEG."""
from pathlib import Path
from PIL import Image, ImageDraw
BASE = Path(__file__).resolve().parents[1]
NAMES = [
    "林间婚礼_精选_001.jpg",
    "林间婚礼_精选_002.jpg",
    "城市建筑外景_秋季作品集_交付客户最终确认版本_摄影师复核_高分辨率原片_请保留文件名_001.jpg",
    "秋日古建筑_庭院光影_003.jpg",
    "山间湖泊_日出_004.png",
]

def paint(path, scene=0):
    width, height = 1600, 1000
    image = Image.new("RGB", (width, height))
    draw = ImageDraw.Draw(image)
    palettes = [(185, 164, 111), (149, 171, 142), (114, 162, 181), (182, 136, 88), (143, 161, 178)]
    red, green, blue = palettes[scene % len(palettes)]
    for y in range(height):
        delta = int(65 * y / height)
        draw.line((0,y,width,y), fill=(max(0,red-delta),max(0,green-delta),max(0,blue-delta)))
    if scene == 0:
        for x in range(0, 1600, 130):
            draw.rectangle((x,0,x+25,900),fill=(59,64,44))
            draw.ellipse((x-180,-200,x+350,230), fill=(94,109,57))
        draw.polygon([(600,900),(750,460),(840,460),(1030,900)], fill=(237,225,192))
        draw.ellipse((749,390,843,484),fill=(192,159,123))
    elif scene == 1:
        for x,y,r in [(650,420,110),(850,410,120),(740,590,140),(980,570,90),(540,600,90)]:
            draw.ellipse((x-r,y-r,x+r,y+r), fill=(242,233,208))
            draw.ellipse((x-20,y-20,x+20,y+20),fill=(190,168,110))
        draw.polygon([(600,750),(790,1000),(1080,700)],fill=(192,205,163))
    elif scene == 2:
        draw.rectangle((0,740,1600,1000),fill=(90,122,131))
        for index in range(11):
            x = 70 + index * 145
            top = 220 + ((index*173)%380)
            draw.rectangle((x,top,x+95,740), fill=(64+index*8,86+index*5,96+index*4))
            for y in range(top+20,720,40):
                draw.line((x+15,y,x+80,y),fill=(187,188,154),width=6)
    elif scene == 3:
        draw.rectangle((250,450,1450,900),fill=(101,67,44))
        draw.polygon([(150,460),(750,210),(1540,460)],fill=(63,63,57))
        draw.rectangle((700,570,1000,900),fill=(49,44,41))
        for x in range(100,500,95): draw.ellipse((x,70,x+220,280),fill=(210,155,45))
    else:
        draw.polygon([(0,730),(350,280),(720,750)], fill=(77,96,111))
        draw.polygon([(450,750),(1000,170),(1600,750)], fill=(64,82,101))
        draw.rectangle((0,750,1600,1000), fill=(87,122,135))
        draw.polygon([(450,750),(1000,970),(1600,750)],fill=(73,104,122))
    image.save(path)


def create():
    folder=BASE / "sample-inputs"
    folder.mkdir(exist_ok=True)
    for index,name in enumerate(NAMES):
        path=folder/name
        if index == 3: path.write_bytes(b"This is an intentionally corrupt sample JPEG, not a real photograph.\n")
        else: paint(path,index)
    (folder / "SAMPLES.txt").write_text("这些是代码绘制的测试样例，不是真实摄影作品。秋日古建筑 JPEG 被刻意损坏，用于实际失败与修复重试测试。\n",encoding="utf-8")
    return [folder/name for name in NAMES]

if __name__ == "__main__":
    for path in create(): print(path)
