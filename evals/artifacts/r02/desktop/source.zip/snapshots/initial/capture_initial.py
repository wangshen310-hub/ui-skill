from pathlib import Path
import json, os, platform
from PySide6 import __version__
from PySide6.QtCore import QTimer
from app import make_application, QueueWindow
from fixtures import create, BASE
app=make_application()
assert app.platformName()=="xcb", app.platformName()
window=QueueWindow(demo=True)
window.add_files(create())
out=BASE/"sample-output"
out.mkdir(exist_ok=True)
window.directory.setText(str(out))
window.show()

def capture():
    assert window.windowHandle().isExposed()
    window.screen().grabWindow(window.winId()).save(str(BASE/"evidence/initial-1100x760.png"))
    metadata={"platform":platform.platform(),"python":platform.python_version(),"pyside":__version__,"qpa":app.platformName(),"display":os.environ["DISPLAY"],"window_id":int(window.winId()),"logical_size":[window.width(),window.height()],"device_pixel_ratio":window.devicePixelRatio(),"exposed":window.windowHandle().isExposed(),"window_manager":"none; actual xcb top-level on Xvfb, no server-side titlebar"}
    (BASE/"evidence/environment-initial.json").write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
    print(json.dumps(metadata,ensure_ascii=False))
    app.quit()
QTimer.singleShot(700,capture)
app.exec()
