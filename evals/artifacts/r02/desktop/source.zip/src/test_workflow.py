"""Integration tests against an exposed native xcb QWidget and real image files."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, time, traceback
from PIL import Image
from PySide6.QtCore import Qt, QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QFileDialog, QLineEdit, QTextEdit
from app import QueueWindow, make_application
from fixtures import BASE, create, paint, NAMES

app=make_application()
assert app.platformName()=="xcb", "No offscreen substitution allowed"
window=QueueWindow(demo=True)
window.show()
QTest.qWait(250)
window.activateWindow()
subprocess.run(["xdotool","windowfocus","--sync",str(int(window.winId()))],check=True)
QTest.qWait(100)
assert window.isActiveWindow(), "X11 window must receive focus before testing shortcuts"
assert window.windowHandle().isExposed()
paths=create()
output=BASE/"test-output"
if output.exists(): shutil.rmtree(output)
output.mkdir()
records=[]
errors=[]

def record(name, **evidence):
    result={"check":name,"result":"passed",**evidence}
    records.append(result)
    print(json.dumps(result,ensure_ascii=False),flush=True)

def screenshot(name):
    QTest.qWait(160)
    path=BASE/"evidence"/name
    assert window.screen().grabWindow(window.winId()).save(str(path))
    return str(path)

def modal(action):
    def callback():
        try:
            dialog=next(d for d in app.topLevelWidgets() if isinstance(d,QFileDialog) and d.isVisible())
            action(dialog)
        except Exception as exc:
            errors.append(traceback.format_exc())
            for d in app.topLevelWidgets():
                if isinstance(d,QFileDialog): d.reject()
    QTimer.singleShot(180,callback)

def wait_finished():
    deadline=time.monotonic()+30
    while (window.running() or window.progress.isVisible()) and time.monotonic()<deadline:
        QTest.qWait(20)
    QTest.qWait(120)
    assert not window.running(), "Export did not finish"
    assert not window.progress.isVisible(), "Finished UI callback did not run"

def files():
    return sorted(p for p in output.iterdir() if p.is_file() and not p.name.startswith("."))

try:
    screenshot("empty-1100x760.png")
    assert not window.export_button.isEnabled()
    assert not window.retry_button.isEnabled()
    record("empty queue disables export and retry")

    def select_inputs(dialog):
        dialog.setDirectory(str(paths[0].parent))
        edit=dialog.findChild(QLineEdit,"fileNameEdit")
        assert edit is not None
        edit.setText(" ".join('"'+p.name+'"' for p in paths))
        edit.setFocus()
        QTest.keyClick(edit,Qt.Key.Key_Return)
    modal(select_inputs)
    QTest.keyClick(window,Qt.Key.Key_O,Qt.KeyboardModifier.ControlModifier)
    assert not errors, errors
    assert window.table.rowCount()==5, window.table.rowCount()
    record("Ctrl+O file picker imports five Unicode-named sample files",filenames=[p.name for p in paths])

    window.activateWindow()
    subprocess.run(["xdotool","windowfocus","--sync",str(int(window.winId()))],check=True)
    QTest.qWait(60)
    window.add_button.setFocus()
    QTest.keyClick(window.add_button,Qt.Key.Key_Tab)
    assert app.focusWidget() is window.all_check, str(app.focusWidget())
    QTest.keyClick(window.all_check,Qt.Key.Key_Tab)
    assert app.focusWidget() is window.table, str(app.focusWidget())
    QTest.keyClick(window.table,Qt.Key.Key_Tab,Qt.KeyboardModifier.ShiftModifier)
    assert app.focusWidget() is window.all_check
    QTest.keyClick(window.all_check,Qt.Key.Key_Tab)
    window.table.setCurrentCell(0,2)
    QTest.keyClick(window.table,Qt.Key.Key_Down)
    assert window.table.currentRow()==1
    QTest.keyClick(window.table,Qt.Key.Key_Space)
    assert len(window.selected_rows())==4
    QTest.keyClick(window.table,Qt.Key.Key_Space)
    assert len(window.selected_rows())==5
    screenshot("keyboard-focus-1100x760.png")
    record("Tab, Shift+Tab, arrow navigation, Space checkbox toggle",focus=app.focusWidget().objectName())

    window.table.setCurrentCell(2,2)
    QTest.keyClick(window.table,Qt.Key.Key_C,Qt.KeyboardModifier.ControlModifier)
    assert QApplication.clipboard().text()==NAMES[2]
    dialog_assertions=[]
    def inspect_details():
        try:
            dialog=next(d for d in app.topLevelWidgets() if d.objectName()=="fileDetails" and d.isVisible())
            content=dialog.findChild(QTextEdit).toPlainText()
            assert NAMES[2] in content
            dialog.screen().grabWindow(dialog.winId()).save(str(BASE/"evidence/long-name-details.png"))
            dialog_assertions.append(True)
            QTest.keyClick(dialog,Qt.Key.Key_Escape)
        except Exception:
            errors.append(traceback.format_exc())
            for d in app.topLevelWidgets():
                if d.objectName()=="fileDetails": d.reject()
    QTimer.singleShot(120,inspect_details)
    QTest.keyClick(window.table,Qt.Key.Key_Return)
    assert not errors, errors
    window.activateWindow()
    subprocess.run(["xdotool","windowfocus","--sync",str(int(window.winId()))],check=True)
    QTest.qWait(60)
    assert dialog_assertions and app.focusWidget() is window.table
    record("long Chinese filename copied in full and shown in Enter dialog; Escape closes dialog",focus_note="main X11 window explicitly refocused by harness because Xvfb has no window manager",utf8_bytes=len(NAMES[2].encode("utf-8")))

    modal(lambda d: QTest.keyClick(d,Qt.Key.Key_Escape))
    QTest.keyClick(window,Qt.Key.Key_O,Qt.KeyboardModifier.ControlModifier)
    assert not errors
    assert window.table.rowCount()==5
    window.activateWindow()
    subprocess.run(["xdotool","windowfocus","--sync",str(int(window.winId()))],check=True)
    QTest.qWait(60)
    record("Escape cancels file selection without modifying queue")

    QTest.mouseClick(window.all_check,Qt.MouseButton.LeftButton)
    assert len(window.selected_rows())==0 and not window.export_button.isEnabled()
    QTest.mouseClick(window.all_check,Qt.MouseButton.LeftButton)
    assert len(window.selected_rows())==5
    record("select all toggles export selection and action availability")

    window.directory.clear()
    QTest.mouseClick(window.export_button,Qt.MouseButton.LeftButton)
    assert "先选择输出目录" in window.feedback.text()
    assert app.focusWidget() is window.directory
    assert not files()
    window.directory.setText(str(BASE/"does-not-exist"))
    QTest.keyClick(window,Qt.Key.Key_Return,Qt.KeyboardModifier.ControlModifier)
    assert "输出目录不存在" in window.feedback.text()
    assert not files()
    record("missing and invalid output directories prevent export and focus the directory field")

    def select_directory(dialog):
        dialog.setDirectory(str(output.parent))
        edit=dialog.findChild(QLineEdit,"fileNameEdit")
        assert edit is not None
        edit.setText(str(output))
        edit.setFocus()
        QTest.keyClick(edit,Qt.Key.Key_Return)
    modal(select_directory)
    QTest.mouseClick(window.directory_button,Qt.MouseButton.LeftButton)
    assert not errors, errors
    assert Path(window.directory.text())==output, window.directory.text()
    window.activateWindow()
    subprocess.run(["xdotool","windowfocus","--sync",str(int(window.winId()))],check=True)
    QTest.qWait(60)
    record("directory picker chooses actual isolated output directory",path=str(output))

    source_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    QTest.keyClick(window,Qt.Key.Key_Return,Qt.KeyboardModifier.ControlModifier)
    wait_finished()
    states=[entry.state for entry in window.entries]
    assert states==["done","done","done","failed","done"], states
    assert len(files())==4, files()
    output_details=[]
    for p in files():
        with Image.open(p) as image:
            image.load()
            assert image.format=="JPEG" and image.size==(1600,1000)
            output_details.append({"path":str(p),"bytes":p.stat().st_size,"format":image.format,"dimensions":list(image.size)})
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in source_hashes.items())
    assert window.retry_button.isEnabled()
    window.table.setCurrentCell(3,2)
    screenshot("export-failure-1100x760.png")
    record("Ctrl+Enter performs real JPEG export; four files reopen and corrupt source fails",states=states,outputs=output_details,source_files_unchanged=True,error=window.entries[3].detail)

    window.resize(720,600)
    QTest.qWait(150)
    window.table.setCurrentCell(2,2)
    window.table.scrollToItem(window.table.item(2,2))
    narrow=screenshot("narrow-720x600.png")
    assert window.sample_label.isVisible(), "Sample-data label must remain visible in narrow windows"
    assert window.table.isColumnHidden(3)
    assert NAMES[2] in window.selection.text()
    assert window.export_button.isVisible() and window.rect().contains(window.export_button.geometry())
    assert window.directory_button.isVisible() and window.rect().contains(window.directory_button.geometry())
    window.resize(680,500)
    QTest.qWait(150)
    screenshot("minimum-680x500.png")
    for widget in [window.export_button,window.directory_button,window.format,window.quality]:
        assert widget.isVisible() and window.rect().contains(widget.geometry()), widget.objectName()
    record("720×600 and minimum 680×500 preserve main controls; long name remains in detail line; dimensions column collapses",screenshot=narrow)

    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files()}
    paint(paths[3],3)
    QTest.keyClick(window,Qt.Key.Key_R,Qt.KeyboardModifier.ControlModifier)
    wait_finished()
    assert [entry.state for entry in window.entries]==["done"]*5
    assert len(files())==5
    assert all(hashlib.sha256((output/name).read_bytes()).hexdigest()==digest for name,digest in before.items())
    with Image.open(window.entries[3].output) as repaired:
        repaired.load()
        assert repaired.size==(1600,1000)
    assert not window.retry_button.isEnabled()
    assert window.entries[3].dimensions=="1600 × 1000"
    assert not window.table.cellWidget(3,1).pixmap().isNull()
    window.resize(1100,760)
    window.table.scrollToTop()
    screenshot("retry-success-1100x760.png")
    record("repair corrupt source then Ctrl+R retries only failed item; all five outputs reopen",new_output=window.entries[3].output,successful_outputs_unchanged=True)

    # Re-export only one item as JPEG, then PNG: existing output remains unchanged.
    window.toggle_all(False)
    window.table.item(0,0).setCheckState(Qt.CheckState.Checked)
    original=output/NAMES[0]
    original_hash=hashlib.sha256(original.read_bytes()).hexdigest()
    QTest.mouseClick(window.export_button,Qt.MouseButton.LeftButton)
    wait_finished()
    assert len(files())==6
    assert hashlib.sha256(original.read_bytes()).hexdigest()==original_hash
    collision_path=Path(window.entries[0].output)
    assert collision_path.name==paths[0].stem+"_1.jpg"
    window.format.setFocus()
    QTest.keyClick(window.format,Qt.Key.Key_Down)
    assert window.format.currentText()=="PNG" and not window.quality.isEnabled()
    QTest.keyClick(window,Qt.Key.Key_Return,Qt.KeyboardModifier.ControlModifier)
    wait_finished()
    assert len(files())==7
    with Image.open(window.entries[0].output) as png:
        png.load()
        assert png.format=="PNG" and png.size==(1600,1000)
    record("repeat export avoids overwriting; keyboard format selection exports a real PNG",collision_output=str(collision_path),png_output=window.entries[0].output)

    # Scroll and remove are actual queue actions and do not remove source files.
    window.table.setCurrentCell(4,2)
    window.table.setFocus()
    QTest.keyClick(window.table,Qt.Key.Key_Delete)
    assert len(window.entries)==4 and paths[4].exists()
    QTest.keyClick(window,Qt.Key.Key_D,Qt.KeyboardModifier.AltModifier)
    assert app.focusWidget() is window.directory
    record("Delete removes a queue row without deleting its source; Alt+D focuses output directory")

    report={"status":"passed","qpa":app.platformName(),"display":os.environ["DISPLAY"],"window_exposed":window.windowHandle().isExposed(),"checks":records,"output_count":len(files())}
except Exception:
    report={"status":"failed","checks":records,"exception":traceback.format_exc(),"modal_errors":errors}
    print(report["exception"],flush=True)
    screenshot("test-failure.png")
finally:
    (BASE/"evidence/workflow-results.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
    window.close()
    app.processEvents()
if report["status"]!="passed": raise SystemExit(1)
