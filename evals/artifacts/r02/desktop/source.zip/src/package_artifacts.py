"""Package only this isolated case's source, samples and evidence; exclude venv/cache."""
from pathlib import Path
import hashlib,json,zipfile
BASE=Path(__file__).resolve().parents[1]
include=[]
for name in ["README.md","REPORT.md","COMMANDS.md","requirements.txt","run.sh"]:
    include.append(BASE/name)
for name in ["src","evidence","snapshots/initial","sample-inputs","test-output","sample-output","native-deps/root"]:
    include.extend(p for p in (BASE/name).rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.name!="artifact-manifest.json")
manifest=[{"path":str(p.relative_to(BASE)),"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(include)]
manifest_path=BASE/"evidence/artifact-manifest.json"
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
archive=BASE/"source-and-evidence.zip"
with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(include)+[manifest_path]:
        bundle.write(path,arcname="round-0002-desktop/"+str(path.relative_to(BASE)))
print(json.dumps({"archive":str(archive),"bytes":archive.stat().st_size,"files":len(include)+1,"sha256":hashlib.sha256(archive.read_bytes()).hexdigest()}))
