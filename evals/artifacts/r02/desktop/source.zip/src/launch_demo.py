"""Start clearly labelled local samples. This app never connects to business data."""
from app import make_application, QueueWindow
from fixtures import BASE, create
app=make_application()
window=QueueWindow(demo=True)
window.add_files(create())
out=BASE/"sample-output"
out.mkdir(exist_ok=True)
window.directory.setText(str(out))
window.show()
raise SystemExit(app.exec())
