"""Launch the delivered shell entrypoint as a separate native process and use XTest keys."""
import json, os, shutil, subprocess, time, traceback
from PIL import Image
from PySide6.QtWidgets import QApplication
from fixtures import BASE
app=QApplication([])
assert app.platformName()=="xcb"
output=BASE/"sample-output"
if output.exists(): shutil.rmtree(output)
output.mkdir()
log=(BASE/"evidence/launcher-app.log").open("w")
process=subprocess.Popen([str(BASE/"run.sh")],cwd=BASE,stdout=log,stderr=log)
try:
    deadline=time.monotonic()+15
    window_id=None
    while time.monotonic()<deadline:
        if process.poll() is not None: raise RuntimeError(f"Launcher exited {process.returncode}")
        found=subprocess.run(["xdotool","search","--onlyvisible","--pid",str(process.pid),"--name","底片 · 批量导出"],capture_output=True,text=True)
        if found.returncode==0 and found.stdout.strip():
            window_id=int(found.stdout.splitlines()[0]); break
        time.sleep(.1)
    assert window_id, "No visible native X11 window from delivered entrypoint"
    subprocess.run(["xdotool","windowfocus","--sync",str(window_id)],check=True)
    geometry=subprocess.run(["xdotool","getwindowgeometry","--shell",str(window_id)],capture_output=True,text=True,check=True).stdout
    time.sleep(.2)
    assert app.primaryScreen().grabWindow(window_id).save(str(BASE/"evidence/launcher-ready-1100x760.png"))
    # This uses the X server's keyboard injection, not a call to an export method.
    subprocess.run(["xdotool","key","--clearmodifiers","ctrl+Return"],check=True)
    deadline=time.monotonic()+20
    outputs=[]
    while time.monotonic()<deadline:
        outputs=[p for p in output.iterdir() if p.is_file() and not p.name.startswith(".")]
        if len(outputs)==4: break
        time.sleep(.1)
    assert len(outputs)==4, str(outputs)
    details=[]
    for path in outputs:
        with Image.open(path) as image:
            image.load()
            assert image.format=="JPEG" and image.size==(1600,1000)
            details.append({"path":str(path),"format":image.format,"size":list(image.size),"bytes":path.stat().st_size})
    time.sleep(.3)
    assert app.primaryScreen().grabWindow(window_id).save(str(BASE/"evidence/launcher-export-result-1100x760.png"))
    report={"status":"passed","entrypoint":"./run.sh","process_id":process.pid,"native_x11_window_id":window_id,"qpa":app.platformName(),"display":os.environ["DISPLAY"],"input":"xdotool key --clearmodifiers ctrl+Return (XTest keyboard events)","geometry":geometry,"outputs":details,"expected_corrupt_source":"秋日古建筑_庭院光影_003.jpg"}
except Exception:
    report={"status":"failed","exception":traceback.format_exc()}
finally:
    process.terminate()
    try: process.wait(timeout=5)
    except subprocess.TimeoutExpired: process.kill();process.wait()
    log.close()
    (BASE/"evidence/launcher-results.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False,indent=2))
if report["status"]!="passed": raise SystemExit(1)
