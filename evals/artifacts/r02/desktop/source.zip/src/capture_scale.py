from pathlib import Path
import json, os, subprocess
from PySide6.QtCore import QTimer
from app import make_application, QueueWindow
from fixtures import BASE, create
app=make_application()
assert app.platformName()=="xcb"
window=QueueWindow(demo=True)
window.add_files(create())
window.directory.setText(str(BASE/"sample-output"))
scaled=os.environ.get("QT_SCALE_FACTOR")=="1.5"
window.resize(900,640) if scaled else window.resize(1100,760)
window.show()
window.activateWindow()
subprocess.run(["xdotool","windowfocus","--sync",str(int(window.winId()))],check=True)
window.add_button.setFocus()
def capture():
    assert window.windowHandle().isExposed()
    name="scale150-900x640.png" if scaled else "final-1100x760.png"
    screenshot=window.screen().grabWindow(window.winId())
    assert screenshot.save(str(BASE/"evidence"/name))
    metadata={"qpa":app.platformName(),"display":os.environ["DISPLAY"],"logical_size":[window.width(),window.height()],"image_pixels":[screenshot.width(),screenshot.height()],"device_pixel_ratio":window.devicePixelRatio(),"scale_factor":os.environ.get("QT_SCALE_FACTOR","1"),"sample_label_visible":window.sample_label.isVisible(),"controls_visible":all(w.isVisible() and window.rect().contains(w.geometry()) for w in [window.export_button,window.directory_button,window.format,window.quality]),"window_exposed":window.windowHandle().isExposed()}
    (BASE/"evidence"/("scale150.json" if scaled else "final-window.json")).write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
    print(json.dumps(metadata,ensure_ascii=False))
    app.quit()
QTimer.singleShot(400,capture)
app.exec()
