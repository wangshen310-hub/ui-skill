"""底片: isolated native photography export queue. No business/network integration."""
from __future__ import annotations
import argparse
import errno
import os
from pathlib import Path
import tempfile
import uuid
from dataclasses import dataclass
from PIL import Image, ImageOps, UnidentifiedImageError
from PySide6.QtCore import Qt, QThread, Signal, QLibraryInfo, QTranslator
from PySide6.QtGui import QColor, QFont, QKeySequence, QPixmap, QShortcut
from PySide6.QtWidgets import (QApplication, QWidget, QLabel, QPushButton, QVBoxLayout,
    QHBoxLayout, QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QFileDialog, QLineEdit, QComboBox, QSpinBox, QCheckBox, QProgressBar,
    QDialog, QDialogButtonBox, QTextEdit)


@dataclass
class Entry:
    uid: str
    path: Path
    state: str = "pending"
    detail: str = ""
    output: str = ""
    dimensions: str = "—"


def readable_error(exc: Exception) -> str:
    if isinstance(exc, FileNotFoundError):
        return "原文件不存在；恢复文件后可重试"
    if isinstance(exc, PermissionError):
        return "没有读取或写入权限；检查文件与输出目录"
    if isinstance(exc, UnidentifiedImageError):
        return "无法读取图片；修复原文件后可重试"
    if isinstance(exc, OSError):
        if exc.errno == errno.ENOSPC:
            return "输出目录空间不足；腾出空间后可重试"
        return "图片或输出目录无法访问：" + str(exc)
    return "导出失败：" + str(exc)


def export_image(source: Path, directory: Path, fmt: str, quality: int) -> Path:
    """Decode, transform orientation, encode, verify, publish without overwriting."""
    with Image.open(source) as original:
        original.load()
        image = ImageOps.exif_transpose(original)
        if fmt == "JPEG":
            if image.mode in ("RGBA", "LA") or "transparency" in image.info:
                rgba = image.convert("RGBA")
                flat = Image.new("RGB", image.size, "white")
                flat.paste(rgba, mask=rgba.getchannel("A"))
                image = flat
            else:
                image = image.convert("RGB")
        elif image.mode not in ("RGB", "RGBA", "L", "LA", "P"):
            image = image.convert("RGB")
        suffix = ".jpg" if fmt == "JPEG" else ".png"
        # Leave room for collision suffixes even for near-limit Chinese names.
        stem = source.stem.encode("utf-8")[:220].decode("utf-8", errors="ignore")
        handle, temp_name = tempfile.mkstemp(prefix=".export-", suffix=suffix, dir=directory)
        os.close(handle)
        temp_path = Path(temp_name)
        try:
            options = {"quality": quality, "optimize": True} if fmt == "JPEG" else {}
            image.save(temp_path, format=fmt, **options)
            with Image.open(temp_path) as check:
                check.verify()
            collision = 0
            while True:
                name = stem + (f"_{collision}" if collision else "") + suffix
                output = directory / name
                try:
                    os.link(temp_path, output)
                    break
                except FileExistsError:
                    collision += 1
            return output
        finally:
            temp_path.unlink(missing_ok=True)


class ExportWorker(QThread):
    started_item = Signal(str)
    finished_item = Signal(str, bool, str)

    def __init__(self, jobs, directory, fmt, quality):
        super().__init__()
        self.jobs = jobs
        self.directory = directory
        self.fmt = fmt
        self.quality = quality

    def run(self):
        for uid, path in self.jobs:
            if self.isInterruptionRequested():
                break
            self.started_item.emit(uid)
            try:
                output = export_image(path, self.directory, self.fmt, self.quality)
                self.finished_item.emit(uid, True, str(output))
            except Exception as exc:
                self.finished_item.emit(uid, False, readable_error(exc))


STYLE = """
QWidget { background: #f5f4f1; color: #27292d; font-family: 'Noto Sans CJK SC'; font-size: 13px; }
QLabel { background: transparent; }
QLabel#title { font-size: 24px; font-weight: 700; }
QLabel#muted, QLabel#hint { color: #73746f; font-size: 12px; }
QLabel#section { font-size: 14px; font-weight: 650; }
QPushButton { background: #fff; border: 1px solid #c9c9c4; border-radius: 4px; padding: 7px 14px; min-height: 20px; }
QPushButton:hover { background: #eeece6; }
QPushButton:focus { border: 2px solid #b44a0a; padding: 6px 13px; }
QPushButton:disabled { color: #999b94; background: #f5f4f1; border-color: #d6d7d1; }
QPushButton#primary { background: #bf4e0a; color: #fff; border: 1px solid #a94208; font-weight: 600; min-width: 160px; }
QPushButton#primary:hover { background: #a94208; }
QPushButton#primary:focus { border: 2px solid #602d0e; }
QPushButton#primary:disabled { background: #d4c4b9; border-color: #c4b4a9; color: #fff; }
QLineEdit, QComboBox, QSpinBox { background: #fff; border: 1px solid #c9c9c4; border-radius: 4px; padding: 6px 9px; min-height: 20px; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus { border: 2px solid #b44a0a; padding: 5px 8px; }
QTableWidget { background: white; border: 1px solid #d2d1cb; border-radius: 3px; gridline-color: #e9e7e2; selection-background-color: #fff0e0; selection-color: #27292d; }
QTableWidget:focus { border: 2px solid #b85a23; }
QTableWidget::item { padding: 9px 10px; border-bottom: 1px solid #e9e7e2; }
QTableWidget::item:selected { background: #fff1e4; color: #27292d; }
QHeaderView::section { background: #f9f9f7; border: none; border-bottom: 1px solid #d2d1cb; color: #686b65; padding: 10px 12px; font-weight: 500; }
QCheckBox { spacing: 7px; background: transparent; }
QCheckBox::indicator { width: 16px; height: 16px; }
QCheckBox:focus { color: #b44a0a; }
QProgressBar { border: none; background: #e7dfd6; max-height: 3px; }
QProgressBar::chunk { background: #bf4e0a; }
QTextEdit { background: #fff; border: 1px solid #d2d1cb; padding: 10px; }
QToolTip { color: #262824; background: #fffdf7; border: 1px solid #bfbdb5; padding: 6px; }
"""


class QueueWindow(QWidget):
    def __init__(self, demo=False):
        super().__init__()
        self.setObjectName("queueWindow")
        self.setWindowTitle("底片 · 批量导出")
        self.resize(1100, 760)
        self.setMinimumSize(680, 500)
        self.entries: list[Entry] = []
        self.worker = None
        self.completed = 0
        self.shortcuts = []
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 16)
        root.setSpacing(12)
        header = QHBoxLayout()
        title = QLabel("批量导出")
        title.setObjectName("title")
        header.addWidget(title)
        self.sample_label = QLabel("样例文件 · 不连接业务" if demo else "")
        self.sample_label.setObjectName("muted")
        header.addSpacing(12)
        header.addWidget(self.sample_label)
        header.addStretch()
        self.add_button = QPushButton("添加图片…")
        self.add_button.setObjectName("addButton")
        self.add_button.setAccessibleName("添加图片，Ctrl+O")
        self.add_button.setToolTip("选择本地图片（Ctrl+O）")
        self.add_button.clicked.connect(self.choose_files)
        header.addWidget(self.add_button)
        root.addLayout(header)
        toolbar = QHBoxLayout()
        section = QLabel("导出队列")
        section.setObjectName("section")
        toolbar.addWidget(section)
        toolbar.addSpacing(12)
        self.all_check = QCheckBox("全选")
        self.all_check.setObjectName("allCheck")
        self.all_check.clicked.connect(self.toggle_all)
        toolbar.addWidget(self.all_check)
        self.count_label = QLabel("0 张")
        self.count_label.setObjectName("muted")
        toolbar.addWidget(self.count_label)
        toolbar.addStretch()
        self.remove_button = QPushButton("移除")
        self.remove_button.setToolTip("移除当前行（Delete），不删除原文件")
        self.remove_button.clicked.connect(self.remove_current)
        toolbar.addWidget(self.remove_button)
        self.retry_button = QPushButton("重试失败")
        self.retry_button.setObjectName("retryButton")
        self.retry_button.setToolTip("重试所有失败项目（Ctrl+R）")
        self.retry_button.clicked.connect(self.retry_failed)
        toolbar.addWidget(self.retry_button)
        root.addLayout(toolbar)
        self.table = QTableWidget(0, 5)
        self.table.setObjectName("queueTable")
        self.table.setAccessibleName("导出队列，方向键浏览，空格勾选，Enter 查看完整文件名")
        self.table.setHorizontalHeaderLabels(["", "预览", "文件名", "尺寸", "导出状态"])
        self.table.verticalHeader().hide()
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setShowGrid(False)
        self.table.setWordWrap(True)
        self.table.setTextElideMode(Qt.TextElideMode.ElideMiddle)
        self.table.setTabKeyNavigation(False)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0, 36)
        self.table.setColumnWidth(1, 88)
        self.table.setColumnWidth(3, 130)
        self.table.setColumnWidth(4, 190)
        self.table.itemChanged.connect(self.update_controls)
        self.table.currentCellChanged.connect(self.show_selection)
        self.table.cellDoubleClicked.connect(lambda *_: self.show_details())
        root.addWidget(self.table, 1)
        self.selection = QLabel("添加本地图片，选择输出目录后导出。")
        self.selection.setObjectName("muted")
        self.selection.setWordWrap(True)
        self.selection.setTextFormat(Qt.TextFormat.PlainText)
        self.selection.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.selection.setMinimumHeight(20)
        root.addWidget(self.selection)
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.hide()
        root.addWidget(self.progress)
        out = QHBoxLayout()
        out.addWidget(QLabel("输出目录"))
        self.directory = QLineEdit()
        self.directory.setObjectName("outputDirectory")
        self.directory.setAccessibleName("输出目录")
        self.directory.setPlaceholderText("选择本地文件夹")
        self.directory.textChanged.connect(lambda text: self.directory.setToolTip(text))
        out.addWidget(self.directory, 1)
        self.directory_button = QPushButton("选择目录…")
        self.directory_button.setObjectName("chooseDirectory")
        self.directory_button.clicked.connect(self.choose_directory)
        out.addWidget(self.directory_button)
        root.addLayout(out)
        export_row = QHBoxLayout()
        self.format = QComboBox()
        self.format.setAccessibleName("导出格式")
        self.format.addItems(["JPEG", "PNG"])
        self.format.setFixedWidth(108)
        self.format.currentTextChanged.connect(lambda text: self.quality.setEnabled(text == "JPEG"))
        export_row.addWidget(self.format)
        export_row.addSpacing(10)
        self.quality_label = QLabel("质量")
        export_row.addWidget(self.quality_label)
        self.quality = QSpinBox()
        self.quality.setAccessibleName("JPEG 质量")
        self.quality.setRange(1, 100)
        self.quality.setValue(90)
        self.quality.setFixedWidth(85)
        export_row.addWidget(self.quality)
        self.size_hint = QLabel("保留原图尺寸")
        self.size_hint.setObjectName("muted")
        export_row.addSpacing(12)
        export_row.addWidget(self.size_hint)
        export_row.addStretch()
        self.export_button = QPushButton("导出所选")
        self.export_button.setObjectName("primary")
        self.export_button.clicked.connect(self.export_selected)
        export_row.addWidget(self.export_button)
        root.addLayout(export_row)
        self.feedback = QLabel("")
        self.feedback.setObjectName("feedback")
        self.feedback.setWordWrap(True)
        self.feedback.setTextFormat(Qt.TextFormat.PlainText)
        self.feedback.hide()
        root.addWidget(self.feedback)
        self.key_hint = QLabel("Ctrl+O 添加  ·  空格 勾选  ·  Enter 文件详情  ·  Ctrl+Enter 导出")
        self.key_hint.setObjectName("hint")
        self.key_hint.setWordWrap(True)
        root.addWidget(self.key_hint)
        for keys, fn in [("Ctrl+O", self.choose_files), ("Ctrl+Return", self.export_selected),
                         ("Ctrl+Enter", self.export_selected), ("Ctrl+R", self.retry_failed),
                         ("Alt+D", self.directory.setFocus)]:
            shortcut = QShortcut(QKeySequence(keys), self)
            shortcut.activated.connect(fn)
            self.shortcuts.append(shortcut)
        self.table.installEventFilter(self)
        order = [self.add_button, self.all_check, self.table, self.remove_button,
                 self.retry_button, self.directory, self.directory_button, self.format,
                 self.quality, self.export_button]
        for first, second in zip(order, order[1:]):
            QWidget.setTabOrder(first, second)
        self.update_controls()
        self.add_button.setFocus()

    def eventFilter(self, obj, event):
        from PySide6.QtCore import QEvent
        if obj is self.table and event.type() == QEvent.Type.KeyPress:
            row = self.table.currentRow()
            if event.key() == Qt.Key.Key_Space and row >= 0 and not self.running():
                item = self.table.item(row, 0)
                item.setCheckState(Qt.CheckState.Unchecked if item.checkState() == Qt.CheckState.Checked else Qt.CheckState.Checked)
                return True
            if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and not event.modifiers() & Qt.KeyboardModifier.ControlModifier:
                self.show_details()
                return True
            if event.key() == Qt.Key.Key_Delete:
                self.remove_current()
                return True
            if event.matches(QKeySequence.StandardKey.Copy) and row >= 0:
                QApplication.clipboard().setText(self.entries[row].path.name)
                return True
        return super().eventFilter(obj, event)

    def running(self):
        return self.worker is not None and self.worker.isRunning()

    def choose_files(self):
        if self.running(): return
        paths, _ = QFileDialog.getOpenFileNames(self, "添加图片", "", "图片 (*.jpg *.jpeg *.png *.tif *.tiff *.webp *.bmp);;所有文件 (*)")
        if paths: self.add_files(paths)

    def choose_directory(self):
        path = QFileDialog.getExistingDirectory(self, "选择输出目录", self.directory.text() or str(Path.home()))
        if path: self.directory.setText(path)

    def add_files(self, paths):
        known = {entry.path for entry in self.entries}
        self.table.blockSignals(True)
        for value in paths:
            path = Path(value).resolve()
            if path in known: continue
            known.add(path)
            entry = Entry(uuid.uuid4().hex, path)
            preview = QPixmap(str(path))
            if not preview.isNull(): entry.dimensions = f"{preview.width()} × {preview.height()}"
            self.entries.append(entry)
            row = self.table.rowCount()
            self.table.insertRow(row)
            check = QTableWidgetItem()
            check.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsUserCheckable)
            check.setCheckState(Qt.CheckState.Checked)
            check.setData(Qt.ItemDataRole.AccessibleTextRole, "导出 " + path.name)
            self.table.setItem(row, 0, check)
            thumb = QLabel("无预览" if preview.isNull() else "")
            thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
            thumb.setStyleSheet("background: transparent; color: #96988f; font-size: 11px;")
            if not preview.isNull(): thumb.setPixmap(preview.scaled(68, 50, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
            self.table.setCellWidget(row, 1, thumb)
            for col, text in [(2, path.name), (3, entry.dimensions), (4, "○  待导出")]:
                item = QTableWidgetItem(text)
                item.setToolTip(str(path) if col == 2 else text)
                self.table.setItem(row, col, item)
            self.table.setRowHeight(row, 80)
        self.table.blockSignals(False)
        if self.table.currentRow() < 0 and self.entries: self.table.setCurrentCell(0, 2)
        self.update_controls()
        self.show_selection()

    def toggle_all(self, checked):
        self.table.blockSignals(True)
        for row in range(self.table.rowCount()):
            self.table.item(row, 0).setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)
        self.table.blockSignals(False)
        self.update_controls()

    def selected_rows(self):
        return [row for row in range(self.table.rowCount()) if self.table.item(row, 0).checkState() == Qt.CheckState.Checked]

    def update_controls(self, *_):
        busy = self.running()
        selected = self.selected_rows()
        failed = sum(entry.state == "failed" for entry in self.entries)
        self.count_label.setText(f"{len(self.entries)} 张 · 已选 {len(selected)} 张")
        self.export_button.setText("导出中…" if busy else f"导出所选 ({len(selected)})")
        self.export_button.setEnabled(bool(selected) and not busy)
        self.retry_button.setText(f"重试失败 ({failed})" if failed else "重试失败")
        self.retry_button.setEnabled(bool(failed) and not busy)
        self.remove_button.setEnabled(self.table.currentRow() >= 0 and not busy)
        for control in (self.add_button, self.all_check, self.directory, self.directory_button, self.format):
            control.setEnabled(not busy)
        self.quality.setEnabled(not busy and self.format.currentText() == "JPEG")
        self.all_check.blockSignals(True)
        self.all_check.setChecked(bool(self.entries) and len(selected) == len(self.entries))
        self.all_check.blockSignals(False)

    def show_selection(self, *_):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.entries):
            self.selection.setText("添加本地图片，选择输出目录后导出。")
        else:
            entry = self.entries[row]
            extra = ("\n" + entry.detail) if entry.detail else ""
            self.selection.setText(entry.path.name + extra)
            self.selection.setToolTip(str(entry.path) + ("\n输出：" + entry.output if entry.output else ""))
        self.update_controls()

    def show_details(self):
        row = self.table.currentRow()
        if row < 0: return
        entry = self.entries[row]
        dialog = QDialog(self)
        dialog.setObjectName("fileDetails")
        dialog.setWindowTitle("文件详情")
        dialog.resize(650, 300)
        layout = QVBoxLayout(dialog)
        text = QTextEdit()
        text.setReadOnly(True)
        text.setPlainText("文件名\n" + entry.path.name + "\n\n原文件\n" + str(entry.path) + "\n\n" + self.table.item(row, 4).text() + ("\n" + entry.detail if entry.detail else "") + ("\n\n输出文件\n" + entry.output if entry.output else ""))
        text.setAccessibleName("完整文件名、路径与导出状态")
        layout.addWidget(text)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.button(QDialogButtonBox.StandardButton.Close).setText("关闭")
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        dialog.exec()
        self.table.setFocus()

    def remove_current(self):
        if self.running(): return
        row = self.table.currentRow()
        if row >= 0:
            self.entries.pop(row)
            self.table.removeRow(row)
            self.show_selection()

    def notify(self, message, error=False):
        self.feedback.setStyleSheet("color: " + ("#a93626" if error else "#45674f") + "; font-size: 12px;")
        self.feedback.setText(message)
        self.feedback.show()

    def export_selected(self):
        self.start_export(self.selected_rows())

    def retry_failed(self):
        self.start_export([row for row, entry in enumerate(self.entries) if entry.state == "failed"])

    def start_export(self, rows):
        if self.running() or not rows: return
        value = self.directory.text().strip()
        if not value:
            self.notify("请先选择输出目录。", True)
            self.directory.setFocus()
            return
        directory = Path(value).expanduser()
        if not directory.is_dir():
            self.notify("输出目录不存在；请选择已有文件夹。", True)
            self.directory.setFocus()
            return
        self.feedback.hide()
        self.completed = 0
        self.progress.setRange(0, len(rows))
        self.progress.setValue(0)
        self.progress.show()
        self.worker = ExportWorker([(self.entries[row].uid, self.entries[row].path) for row in rows], directory, self.format.currentText(), self.quality.value())
        self.worker.started_item.connect(self.on_started)
        self.worker.finished_item.connect(self.on_result)
        self.worker.finished.connect(self.on_finished)
        self.worker.start()
        self.update_controls()

    def on_started(self, uid):
        row = next(i for i, e in enumerate(self.entries) if e.uid == uid)
        self.entries[row].state = "exporting"
        self.table.item(row, 4).setText("↻  导出中")
        self.table.item(row, 4).setForeground(QColor("#9a5c15"))
        self.table.blockSignals(True)
        for i in range(len(self.entries)):
            self.table.item(i, 0).setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
        self.table.blockSignals(False)

    def on_result(self, uid, success, result):
        row = next(i for i, e in enumerate(self.entries) if e.uid == uid)
        entry = self.entries[row]
        entry.state = "done" if success else "failed"
        entry.output = result if success else ""
        entry.detail = "" if success else result
        if success and entry.dimensions == "—":
            preview = QPixmap(str(entry.path))
            if not preview.isNull():
                entry.dimensions = f"{preview.width()} × {preview.height()}"
                self.table.item(row, 3).setText(entry.dimensions)
                thumbnail = self.table.cellWidget(row, 1)
                thumbnail.setText("")
                thumbnail.setPixmap(preview.scaled(68, 50, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        status = self.table.item(row, 4)
        status.setText("✓  已导出" if success else "!  失败 · 无法导出")
        status.setForeground(QColor("#30734e" if success else "#b23f2f"))
        status.setToolTip(result)
        self.completed += 1
        self.progress.setValue(self.completed)
        self.show_selection()

    def on_finished(self):
        self.progress.hide()
        self.table.blockSignals(True)
        for i in range(len(self.entries)):
            self.table.item(i, 0).setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsUserCheckable)
        self.table.blockSignals(False)
        success = sum(entry.state == "done" for entry in self.entries)
        failed = sum(entry.state == "failed" for entry in self.entries)
        self.notify(f"已导出 {success} 张；{failed} 张失败。修复文件或目录后可重试。" if failed else f"已导出 {success} 张，文件已保存到输出目录。", bool(failed))
        self.update_controls()
        self.table.setFocus()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "table"):
            self.table.setColumnHidden(3, self.width() < 940)
            self.table.setColumnWidth(4, 154 if self.width() < 940 else 190)
            self.sample_label.setVisible(bool(self.sample_label.text()))
            self.size_hint.setVisible(self.width() >= 820)

    def closeEvent(self, event):
        if self.running():
            self.worker.requestInterruption()
            self.worker.wait()
        event.accept()


def make_application():
    app = QApplication.instance() or QApplication([])
    app.setApplicationName("底片")
    translator = QTranslator(app)
    if translator.load("qtbase_zh_CN", QLibraryInfo.path(QLibraryInfo.LibraryPath.TranslationsPath)):
        app.installTranslator(translator)
        app._chinese_translator = translator
    app.setStyle("Fusion")
    app.setFont(QFont("Noto Sans CJK SC", 10))
    app.setStyleSheet(STYLE)
    return app


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--directory", default="")
    parser.add_argument("files", nargs="*")
    args = parser.parse_args()
    app = make_application()
    window = QueueWindow(demo=args.demo)
    window.directory.setText(args.directory)
    if args.files: window.add_files(args.files)
    window.show()
    app.exec()


if __name__ == "__main__":
    main()
