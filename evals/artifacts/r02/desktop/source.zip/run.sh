#!/bin/sh
set -eu
app_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export LD_LIBRARY_PATH="$app_dir/native-deps/root/usr/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
if [ "${1:-}" = "--empty" ]; then
  shift
  exec "$app_dir/.venv/bin/python" "$app_dir/src/app.py" "$@"
fi
exec "$app_dir/.venv/bin/python" "$app_dir/src/launch_demo.py" "$@"
