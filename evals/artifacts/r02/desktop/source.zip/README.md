# 底片 · 批量导出（原生桌面案例）

独立实现的 PySide6 Widgets 桌面应用。界面用文件队列组织摄影工作室的批量导出任务，Pillow 实际解码与编码图片，不连接任何业务或网络接口。

远端目录：`/opt/ui-skill-lab-20261020/round-0002-desktop/`  
控制端源文件与证据：`/tmp/ui-skill-lab-20261020/round-0002-desktop/`

## 运行

在已有 X11 桌面会话中进入远端目录，执行 `./run.sh`。它打开明确标注的代码绘制样例，其中一张 JPEG 被刻意损坏。生成样例会恢复这些隔离样例文件，不处理其他目录。输出保存在当前选择的目录，已有同名文件不会被覆盖。

`./run.sh --empty` 打开空队列，可通过“添加图片…”选择本地文件。

无桌面的服务器可用自带的独立 Xvfb 验证器：

```sh
.venv/bin/python src/headless_runner.py src/test_workflow.py
.venv/bin/python src/headless_runner.py src/verify_launcher.py
```

这里没有打包 Windows/macOS 安装程序；交付是可直接运行的原生 Python 桌面程序和隔离运行环境。

## 操作

- Ctrl+O：添加图片；图片默认加入导出选择。
- Tab / Shift+Tab：在控件间移动；方向键浏览队列；空格切换当前行勾选。
- Enter：查看完整文件名、路径与状态；Escape 关闭详情。
- Ctrl+C：复制当前行的完整文件名。
- Alt+D：聚焦输出目录；也可通过“选择目录…”选择文件夹。
- Ctrl+Enter：导出已勾选文件；Ctrl+R：仅重试失败项目。
- Delete：从队列移除当前行，不删除原文件。

支持 JPEG/PNG，JPEG 质量可调。保留图片尺寸并处理 EXIF 方向；JPEG 的透明区域使用白底。编码完成后重新打开输出校验，再发布到目标文件名；重复名称追加 `_1` 等后缀。

## 证据

- 参考：`evidence/reference.png`；生成提示词：`evidence/imagegen-prompt.txt`。
- 初始实现：`snapshots/initial/app.py`、`snapshots/initial/initial-1100x760.png`。
- 最终主窗口：`evidence/final-1100x760.png`。
- 实际独立入口截图：`evidence/launcher-ready-1100x760.png`、`evidence/launcher-export-result-1100x760.png`。
- 失败与重试：`evidence/export-failure-1100x760.png`、`evidence/retry-success-1100x760.png`。
- 窄窗：`evidence/narrow-720x600.png`、`evidence/minimum-680x500.png`。
- 150% 缩放：`evidence/scale150-900x640.png`，对应 1350×960 像素截图。
- 完整长文件名：`evidence/long-name-details.png`。
- 行为结果：`evidence/workflow-results.json`；独立入口结果：`evidence/launcher-results.json`。
- 命令、环境、限制：`REPORT.md`、`COMMANDS.md`。

源码在 `src/app.py`；样例生成在 `src/fixtures.py`；测试在 `src/test_workflow.py` 与 `src/verify_launcher.py`。
