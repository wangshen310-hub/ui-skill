import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:paper_shelf/main.dart';
import 'package:paper_shelf/storage.dart';

void main() {
  LiveTestWidgetsFlutterBinding().framePolicy = LiveTestWidgetsFlutterBindingFramePolicy.onlyPumps;
  final boundaryKey = GlobalKey();
  late Directory temporary;

  setUpAll(() async {
    for (final pair in [
      ['ShelfSans', 'assets/fonts/NotoSansCJKsc-Regular.otf'],
      ['ShelfSerif', 'assets/fonts/NotoSerifCJKsc-Regular.otf'],
    ]) {
      final loader = FontLoader(pair[0]);
      loader.addFont(Future.value(ByteData.sublistView(await File(pair[1]).readAsBytes())));
      await loader.load();
    }
    final icons = FontLoader('MaterialIcons');
    icons.addFont(rootBundle.load('fonts/MaterialIcons-Regular.otf'));
    await icons.load();
    debugDisableShadows = false;
    temporary = await Directory.systemTemp.createTemp('paper-shelf-engine-');
    await Directory('../evidence/screenshots-final').create(recursive: true);
  });

  tearDownAll(() async => temporary.delete(recursive: true));

  Future<void> screenshot(WidgetTester tester, String name) async {
    await tester.pumpAndSettle();
    final boundary = boundaryKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
    await tester.runAsync(() async {
      final image = await boundary.toImage(pixelRatio: 2);
      expect(image.width, (tester.view.physicalSize.width * 2).round());
      expect(image.height, (tester.view.physicalSize.height * 2).round());
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      await File('../evidence/screenshots-final/$name.png').writeAsBytes(bytes!.buffer.asUint8List());
      debugPrint('ENGINE_SCREENSHOT $name logical=${boundary.size} pixels=${image.width}x${image.height}');
      image.dispose();
    });
  }

  Future<ShelfStore> start(WidgetTester tester, String filename, {Size size = const Size(390, 844), double scale = 1}) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = size;
    tester.view.padding = FakeViewPadding(top: 24, bottom: 24);
    await tester.binding.setSurfaceSize(size);
    final store = ShelfStore(File('${temporary.path}/$filename.json'));
    await tester.runAsync(store.load);
    await tester.pumpWidget(RepaintBoundary(key: boundaryKey, child: ReadingApp(store: store, textScale: scale)));
    await tester.pumpAndSettle();
    return store;
  }

  testWidgets('phone flow, real file persistence, font settings and three books', (tester) async {
    final store = await start(tester, 'flow');
    expect(find.text('三本示例短篇'), findsOneWidget);
    expect(find.text('小城来信'), findsNWidgets(2));
    expect(find.text('山间手记'), findsNWidgets(2));
    expect(find.text('日常观察'), findsNWidgets(2));
    await screenshot(tester, '01-shelf-390x844');
    await tester.tap(find.byKey(const Key('open-letters')));
    await tester.pumpAndSettle();
    expect(find.text('车站外的梧桐'), findsOneWidget);
    await screenshot(tester, '02-reader-390x844');
    await tester.drag(find.byKey(const Key('reader-scroll')), const Offset(0, -600));
    await tester.pumpAndSettle();
    await tester.pump(const Duration(milliseconds: 350));
    final before = tester.state<ReaderState>(find.byType(ReaderPage)).scroll.offset;
    expect(before, greaterThan(400));
    await tester.tap(find.byKey(const Key('back-shelf')));
    await tester.pumpAndSettle();
    await tester.runAsync(() async { await store.save(); });
    expect(find.text('继续阅读'), findsOneWidget);

    // New store and new app recreate the state using actual JSON on disk.
    await tester.pumpWidget(const SizedBox());
    await tester.pumpAndSettle();
    final reloaded = await start(tester, 'flow');
    expect(reloaded.positions['letters']!.paragraph, greaterThan(0));
    await tester.tap(find.byKey(const Key('open-letters')));
    await tester.pumpAndSettle();
    final after = tester.state<ReaderState>(find.byType(ReaderPage)).scroll.offset;
    expect((after - before).abs(), lessThan(2));
    await screenshot(tester, '03-resumed-390x844');
    await tester.tap(find.byKey(const Key('font-settings')));
    await tester.pumpAndSettle();
    await screenshot(tester, '04-font-settings-390x844');
    final slider = find.byKey(const Key('font-slider'));
    final rect = tester.getRect(slider);
    await tester.tapAt(Offset(rect.right - 25, rect.center.dy));
    await tester.pumpAndSettle();
    expect(reloaded.fontSize, greaterThan(23));
    await tester.tap(find.byKey(const Key('font-done')));
    await tester.pumpAndSettle();
    await screenshot(tester, '05-reader-font-large-390x844');
    await tester.tap(find.byKey(const Key('back-shelf')));
    await tester.pumpAndSettle();

    for (final id in ['mountain', 'everyday']) {
      await tester.ensureVisible(find.byKey(Key('open-$id')));
      await tester.tap(find.byKey(Key('open-$id')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('paragraph-0')), findsOneWidget);
      await tester.tap(find.byKey(const Key('back-shelf')));
      await tester.pumpAndSettle();
    }
    await tester.runAsync(() async {
      final verify = ShelfStore(reloaded.file);
      await verify.load();
      expect(verify.fontSize, reloaded.fontSize);
      expect(verify.positions.keys, containsAll(['letters', 'mountain', 'everyday']));
      await File('../evidence/persisted-state-sample.json').writeAsString(await reloaded.file.readAsString());
    });
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('320px width and 200 percent system text remain usable', (tester) async {
    await start(tester, 'narrow', size: const Size(320, 640), scale: 2);
    expect(tester.takeException(), isNull);
    await screenshot(tester, '06-shelf-320x640-scale2');
    for (final id in ['letters', 'mountain', 'everyday']) {
      await tester.ensureVisible(find.byKey(Key('open-$id')));
      final target = tester.getRect(find.byKey(Key('open-$id')));
      expect(target.height, greaterThanOrEqualTo(48));
      await tester.tap(find.byKey(Key('open-$id')));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      if (id == 'letters') await screenshot(tester, '07-reader-320x640-scale2');
      await tester.tap(find.byKey(const Key('font-settings')));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      await tester.tap(find.byKey(const Key('font-done')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('back-shelf')));
      await tester.pumpAndSettle();
    }
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });
}
