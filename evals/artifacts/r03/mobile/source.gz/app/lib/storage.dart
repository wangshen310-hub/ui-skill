import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

class ReadingPosition {
  const ReadingPosition(this.paragraph, this.inside);
  final int paragraph;
  final double inside;
  Map<String, Object> toJson() => {'paragraph': paragraph, 'inside': inside};
}

class ShelfStore extends ChangeNotifier {
  ShelfStore(this.file);
  final File file;
  final Map<String, ReadingPosition> positions = {};
  double fontSize = 19;
  Future<void> _pending = Future.value();

  static Future<ShelfStore> forDevice() async {
    const channel = MethodChannel('paper_shelf/storage');
    final path = await channel.invokeMethod<String>('directory');
    if (path == null) throw const FileSystemException('无法打开设备存储');
    final store = ShelfStore(File('$path/reading-state.json'));
    await store.load();
    return store;
  }

  Future<void> load() async {
    if (!await file.exists()) return;
    final data = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
    fontSize = ((data['fontSize'] as num?)?.toDouble() ?? 19).clamp(16, 28);
    final items = data['positions'] as Map<String, dynamic>? ?? {};
    for (final entry in items.entries) {
      final item = entry.value as Map<String, dynamic>;
      positions[entry.key] = ReadingPosition(
        ((item['paragraph'] as num?)?.toInt() ?? 0).clamp(0, 10000),
        ((item['inside'] as num?)?.toDouble() ?? 0).clamp(0, 100000),
      );
    }
    notifyListeners();
  }

  Future<void> save() {
    final data = jsonEncode({
      'version': 1,
      'fontSize': fontSize,
      'positions': positions.map((key, value) => MapEntry(key, value.toJson())),
    });
    // Serialize writes so a slower older save cannot replace a newer position.
    final task = _pending.catchError((Object _) {}).then((_) async {
      await file.parent.create(recursive: true);
      final temporary = File('${file.path}.tmp');
      await temporary.writeAsString(data, flush: true);
      await temporary.rename(file.path);
    });
    _pending = task;
    notifyListeners();
    return task;
  }
}
