const dates = [
  {day: 21, week: '周三'}, {day: 22, week: '周四'},
  {day: 23, week: '周五'}, {day: 24, week: '周六'},
  {day: 25, week: '周日'}, {day: 26, week: '周一'},
  {day: 27, week: '周二'}
];
const courts = ['1号场', '2号场', '3号场'];
const hours = [
  {start: '17:00', end: '18:00', price: 60},
  {start: '18:00', end: '19:00', price: 80},
  {start: '19:00', end: '20:00', price: 80},
  {start: '20:00', end: '21:00', price: 80}
];

// Fixed, visible local sample data. No remote booking or payment call exists.
function slotsFor(dateIndex, courtIndex) {
  return hours.map((hour, index) => Object.assign({}, hour, {
    id: index,
    full: (dateIndex === 6 && courtIndex === 2) ||
      (index + dateIndex * 2 + courtIndex) % 5 === 2
  }));
}

Component({
  data: {
    dates, courts,
    dateIndex: 0, courtIndex: 1,
    dateLabel: '10月21日 周三', courtLabel: '2号场',
    slots: slotsFor(0, 1), selectedIndex: -1,
    start: '', end: '', total: 0,
    phase: 'choose', allFull: false
  },
  methods: {
    selectDate(event) {
      const index = Number(event.currentTarget.dataset.index);
      if (!Number.isInteger(index) || !dates[index]) return;
      this.changeContext(index, this.data.courtIndex);
    },
    selectCourt(event) {
      const index = Number(event.currentTarget.dataset.index);
      if (!Number.isInteger(index) || !courts[index]) return;
      this.changeContext(this.data.dateIndex, index);
    },
    changeContext(dateIndex, courtIndex) {
      if (dateIndex === this.data.dateIndex && courtIndex === this.data.courtIndex) return;
      const slots = slotsFor(dateIndex, courtIndex);
      this.setData({
        dateIndex, courtIndex, slots,
        dateLabel: '10月' + dates[dateIndex].day + '日 ' + dates[dateIndex].week,
        courtLabel: courts[courtIndex],
        selectedIndex: -1, start: '', end: '', total: 0,
        allFull: slots.every(slot => slot.full), phase: 'choose'
      });
    },
    selectSlot(event) {
      const index = Number(event.currentTarget.dataset.index);
      const slot = this.data.slots[index];
      if (!slot || slot.full) return;
      this.setData({selectedIndex: index, start: slot.start, end: slot.end, total: slot.price});
    },
    review() {
      const slot = this.data.slots[this.data.selectedIndex];
      if (!slot || slot.full) return;
      this.setData({phase: 'review'});
    },
    back() { this.setData({phase: 'choose'}); },
    confirmLocal() {
      if (this.data.phase !== 'review' || this.data.selectedIndex < 0) return;
      this.setData({phase: 'complete'});
    }
  }
});
