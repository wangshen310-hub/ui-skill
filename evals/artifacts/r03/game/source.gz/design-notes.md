固定技能来源：/tmp/ui-skill-lab-20261020/baselines/856ebb6/ui-skill/SKILL.md。
已读取其 references/art-direction.md、references/writing.md、references/verification.md；未读取 evals、旧案例、评审或其他作者报告。

主参考由内置 imagegen 生成并已实际查看：reference/pause-reference.png。
图中可见：无卡片外框的左侧菜单，右侧大蓝灰色暗面行星，细斜轨道，薄荷色削角选中条，简短中文动作和底部按键提示。
实现取值（估计而非测量）：逻辑画布 1440×900；菜单 x=116，宽 432，选中行高64；标题60，动作27，提示17；背景 #071019，文字 #E5EDEA，选中 #C0E9DD。
行星采用独立生成的透明素材；整个参考图不作为应用背景。星点、轨道、飞船、菜单和字由 Pygame 绘制。

交互补充：初始暂停；继续时飞船绕轨运行，暂停时模拟时钟冻结。设置支持星光亮度与轨道指引，修改保存到本项目 settings.json。返回设置上一级时恢复“设置”焦点。返回标题后可开始新航行。
键盘支持上下、Tab/Shift+Tab、Enter/Space、Esc、左右设置调整；控制器支持 D-pad、左右摇杆轴、A/B/Menu。控制器测试如来自测试管道，会明确记 synthetic=true，不能作为实体手柄验证。
1440×900 与 1024×640 等比例渲染；后者动作文字约19px、提示约12px，需要实际截图核对。
