"""Remote-only Xvfb acceptance. Keyboard/window actions use the X server.
Joystick events are explicitly synthetic and cannot prove hardware support.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--smoke", action="store_true")
parser.add_argument("--output-dir", type=Path, help="Fresh evidence directory, relative to the project root or absolute")
args = parser.parse_args()
OUT = args.output_dir or Path("evidence") / ("initial" if args.smoke else "final")
if not OUT.is_absolute():
    OUT = ROOT / OUT
if OUT.exists() and any(OUT.iterdir()):
    parser.error(f"Evidence directory must be empty: {OUT}")
OUT.mkdir(parents=True, exist_ok=True)
PIPE = OUT / "controller.fifo"
results = []
env = os.environ.copy()
env["SDL_AUDIODRIVER"] = "dummy"
env["SDL_VIDEODRIVER"] = "x11"
env["SDL_RENDER_DRIVER"] = "software"
env["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
xvfb = None
app = None
logfile = None


def record(name, **detail):
    entry = {"time": time.time(), "check": name, **detail}
    results.append(entry)
    print(json.dumps(entry, ensure_ascii=False), flush=True)


def state():
    return json.loads((OUT / "state.json").read_text())


def wait_for(predicate, timeout=8):
    start = time.monotonic()
    last = None
    while time.monotonic() - start < timeout:
        if app.poll() is not None:
            raise RuntimeError(f"App exited {app.returncode}")
        try:
            last = state()
            if predicate(last):
                return last
        except (FileNotFoundError, json.JSONDecodeError):
            pass
        time.sleep(.06)
    raise AssertionError(f"State timeout: {last}")


def xdo(*values):
    return subprocess.check_output(["xdotool", *map(str, values)], env=env, text=True).strip()


def window_action(action, *values):
    # SDL may replace the native X11 window after a resize. Refresh its ID for
    # every operation rather than retaining the ID observed at startup.
    snapshot = wait_for(lambda s: s.get("native_window") and s.get("video_driver") == "x11")
    window = snapshot["native_window"]
    output = xdo(action, window, *values)
    if action == "windowsize":
        record("native_resize_request", window_id=window, size=list(values))
    return output


def key(value):
    window_action("windowfocus")
    xdo("key", "--clearmodifiers", value)
    time.sleep(.18)


def check(name, predicate, **detail):
    snapshot = wait_for(predicate)
    record(name, result="passed", state=snapshot, **detail)
    return snapshot


def screenshot(name):
    existing = set(OUT.glob("[0-9][0-9]-*.png"))
    key("F12")
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        created = set(OUT.glob("[0-9][0-9]-*.png")) - existing
        if created:
            path = sorted(created)[0]
            record("screenshot", label=name, path=str(path), state=state())
            return path
        time.sleep(.05)
    raise AssertionError("Screenshot not produced")


def joy(kind, **detail):
    payload = {"type": kind, "instance_id": 0, **detail}
    with PIPE.open("w") as sink:
        sink.write(json.dumps(payload) + "\n")
    time.sleep(.18)


try:
    xvfb_log = (OUT / "xvfb.log").open("w")
    xvfb = subprocess.Popen(["Xvfb", "-displayfd", "1", "-screen", "0", "1600x1000x24", "-nolisten", "tcp"], stdout=subprocess.PIPE, stderr=xvfb_log, text=True)
    display = xvfb.stdout.readline().strip()
    if not display.isdigit():
        raise RuntimeError("Private Xvfb did not report display")
    env["DISPLAY"] = ":" + display
    record("environment", display=env["DISPLAY"], host=os.uname().nodename, source_sha256=__import__("hashlib").sha256((ROOT / "app.py").read_bytes()).hexdigest())
    (OUT / "state.json").unlink(missing_ok=True)
    logfile = (OUT / "app.log").open("w")
    app = subprocess.Popen([sys.executable, str(ROOT / "app.py"), "--evidence-dir", str(OUT), "--test-pipe", str(PIPE)], env=env, stdout=logfile, stderr=subprocess.STDOUT)
    check("startup_paused", lambda s: s["screen"] == "paused" and s["window"] == [1440, 900])
    record("native_window", window_id=state()["native_window"], geometry=window_action("getwindowgeometry"), title=window_action("getwindowname"))
    window_action("windowfocus")
    screenshot("initial-pause-1440")
    if args.smoke:
        record("smoke_only", result="passed")
    else:
        before = state()["simulation_time"]
        time.sleep(.65)
        assert state()["simulation_time"] == before
        record("initial_pause_freezes_simulation", result="passed", before=before, after=state()["simulation_time"])
        key("Return")
        check("keyboard_resume", lambda s: s["screen"] == "flight" and s["simulation_time"] > .15)
        time.sleep(.8)
        screenshot("flight-moving")
        moving = state()
        key("Escape")
        frozen = check("keyboard_pause", lambda s: s["screen"] == "paused")
        time.sleep(.65)
        assert frozen["simulation_time"] == state()["simulation_time"]
        record("pause_freezes_after_flight", result="passed", before=frozen["simulation_time"], after=state()["simulation_time"], prior_moving=moving)
        key("Down")
        key("Return")
        check("keyboard_open_settings", lambda s: s["screen"] == "settings" and s["selection"] == 0)
        key("Left")
        key("Left")
        check("brightness_changes", lambda s: s["settings"]["star_brightness"] == 40)
        key("Down")
        key("Return")
        check("orbit_guides_off", lambda s: not s["settings"]["orbit_guides"])
        screenshot("settings-changed-1440")
        saved = json.loads((ROOT / "settings.json").read_text())
        assert saved == state()["settings"]
        record("settings_file_matches", result="passed", saved=saved)
        key("Escape")
        check("settings_returns_focus", lambda s: s["screen"] == "paused" and s["selection"] == 1)
        key("Tab")
        check("tab_next", lambda s: s["selection"] == 2)
        key("shift+Tab")
        check("shift_tab_previous", lambda s: s["selection"] == 1)
        key("Down")
        key("Return")
        check("return_title", lambda s: s["screen"] == "title" and s["selection"] == 0)
        screenshot("title-1440")
        key("Return")
        check("title_start_flight", lambda s: s["screen"] == "flight" and s["simulation_time"] < 1)
        key("Escape")
        window_action("windowsize", 1024, 640)
        check("resize_to_1024", lambda s: s["window"] == [1024, 640])
        screenshot("pause-1024")
        joy("JOYHATMOTION", hat=0, value=[0, -1])
        check("synthetic_dpad_focus", lambda s: s["selection"] == 1 and s["input_mode"] == "controller", hardware_test=False)
        joy("JOYBUTTONDOWN", button=0)
        check("synthetic_A_settings", lambda s: s["screen"] == "settings" and s["selection"] == 0, hardware_test=False)
        joy("JOYHATMOTION", hat=0, value=[1, 0])
        check("synthetic_setting_adjustment", lambda s: s["settings"]["star_brightness"] == 50, hardware_test=False)
        joy("JOYHATMOTION", hat=0, value=[0, -1])
        joy("JOYBUTTONDOWN", button=0)
        check("synthetic_A_toggle", lambda s: s["settings"]["orbit_guides"], hardware_test=False)
        screenshot("controller-settings-1024")
        joy("JOYBUTTONDOWN", button=1)
        check("synthetic_B_restores_focus", lambda s: s["screen"] == "paused" and s["selection"] == 1, hardware_test=False)
        joy("JOYAXISMOTION", axis=1, value=.8)
        check("synthetic_stick_focus", lambda s: s["selection"] == 2, hardware_test=False)
        joy("JOYBUTTONDOWN", button=0)
        check("synthetic_title", lambda s: s["screen"] == "title", hardware_test=False)
        screenshot("controller-title-1024")
        joy("JOYBUTTONDOWN", button=0)
        check("synthetic_start", lambda s: s["screen"] == "flight", hardware_test=False)
        joy("JOYBUTTONDOWN", button=7)
        check("synthetic_menu_pause", lambda s: s["screen"] == "paused", hardware_test=False)
        joy("JOYBUTTONDOWN", button=1)
        check("synthetic_B_resume", lambda s: s["screen"] == "flight", hardware_test=False)
        joy("JOYBUTTONDOWN", button=7)
        check("synthetic_menu_repause", lambda s: s["screen"] == "paused", hardware_test=False)
        # Restore the shipped visual settings through the real UI.
        key("Down")
        key("Return")
        key("Right")
        check("restore_default_settings", lambda s: s["settings"] == {"star_brightness": 60, "orbit_guides": True})
        screenshot("settings-final-1024")
        key("Escape")
        key("Up")
        screenshot("pause-final-1024")
        window_action("windowsize", 1440, 900)
        check("resize_back_1440", lambda s: s["window"] == [1440, 900] and s["selection"] == 0)
        screenshot("pause-final-1440")
        record("physical_controller", tested=False, count=state()["physical_controllers"], reason="Only explicitly synthetic Pygame joystick events were available")
    # Exit through the actual title menu, preserving a clean application exit.
    while state()["screen"] == "settings":
        key("Escape")
    if state()["screen"] == "flight":
        key("Escape")
    if state()["screen"] == "paused":
        while state()["selection"] != 2:
            key("Down")
        key("Return")
    key("Down")
    key("Down")
    key("Return")
    exit_code = app.wait(timeout=8)
    assert exit_code == 0
    record("clean_ui_exit", result="passed", exit_code=exit_code)
except Exception as error:
    record("failure", error=repr(error))
    raise
finally:
    if app is not None and app.poll() is None:
        app.terminate()
        try:
            app.wait(timeout=5)
        except subprocess.TimeoutExpired:
            app.kill()
            app.wait()
    if xvfb is not None:
        xvfb.terminate()
        try:
            xvfb.wait(timeout=5)
        except subprocess.TimeoutExpired:
            xvfb.kill()
            xvfb.wait()
    if logfile:
        logfile.close()
    if PIPE.exists():
        PIPE.unlink()
    (OUT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
