# 轨道航行

原生 Pygame 场景与暂停菜单。需 Python 3.11、Pygame 2.6.1、SDL/X11，以及 Noto CJK 中文字体；字体路径见 `app.py`。验收另需 Xvfb 和 xdotool。此包不含依赖。

腾讯云现有环境运行：

```sh
cd /opt/ui-skill-lab-20261020/round-0003-game
/opt/ui-skill-validation-20261020/venv/bin/python app.py
```

需图形显示会话。初始暂停，上下或 Tab/Shift+Tab 选择，Enter/Space 确认，Esc 暂停/继续或返回设置上一级，左右调整设置。标题页只显示可用的选择/确认提示。设置保存在同目录 `settings.json`。

无显示器的完整验收会自行启动并清理私有 Xvfb：

```sh
PYTHONDONTWRITEBYTECODE=1 /opt/ui-skill-validation-20261020/venv/bin/python acceptance.py --output-dir evidence/new-run
```

输出目录必须为空。键盘与窗口事件通过 X 服务器，手柄事件通过专用测试管道合成并标记，不能作为实体手柄验证。
