# 运行边界与复现

工程使用 Flutter/Dart 真实组件与 Android 宿主，没有 HTML。`lib/books.dart` 包含三本本案例原创示例短篇；书架明确标为示例，不是出版物信息。

本轮在腾讯云 `tencent-opencloudos` 的隔离目录构建工具并运行 widget test；控制端只编辑、传输和看图。SDK 固定为 3.35.5 官方 tag 源码归档，不宣称最新版。归档没有 git 元数据，专用 SDK 工作树初始化本地快照提交与版本 tag，供 Flutter 工具识别。工具报告的 framework commit 因此是本地快照提交，不能当作官方 commit 验证。引擎版本来自归档内 `bin/internal/engine.version`。

复现（在腾讯云案例根目录）：

```bash
export FLUTTER_STORAGE_BASE_URL=https://storage.flutter-io.cn
export PUB_HOSTED_URL=https://pub.flutter-io.cn
export PUB_CACHE="$PWD/sdk/pub-cache"
export CI=true
cd app
nice -n 15 ../sdk/flutter/bin/flutter --no-version-check pub get
nice -n 15 ../sdk/flutter/bin/flutter --no-version-check analyze --no-pub
nice -n 15 ../sdk/flutter/bin/flutter --no-version-check test --concurrency=1 --reporter=expanded
```

字体：Noto Sans CJK SC 从腾讯云已有系统字体复制，Noto Serif CJK SC 从 `notofonts/noto-cjk` 官方仓库下载。字体采用 SIL Open Font License，随工程保留授权文本。图像参考不进入运行页面；封面为真实 Flutter 文本和简单 CustomPainter 线条。

Android `MainActivity.kt` 通过自有 MethodChannel 返回私有 `filesDir`；Dart 将阅读记录写入 JSON。widget test 注入腾讯云临时目录，测试真实 Dart File 保存和重建对象后的恢复。引擎测试不能证明 Android MethodChannel、安卓文件权限、系统返回、硬件触摸、实际安全区或后台生命周期已在设备上通过。

本轮没有 Android SDK、模拟器或真机，也不构建 APK；不能将截图称为安卓真机截图。截图来自 Flutter widget test 的真实 flutter_tester 引擎 RepaintBoundary，指定逻辑屏幕和模拟安全区，按2倍像素导出。图片内不伪造系统状态栏。
