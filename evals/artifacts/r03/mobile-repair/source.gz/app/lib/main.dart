import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'books.dart';
import 'storage.dart';

const paper = Color(0xFFFAF8F1);
const ink = Color(0xFF242821);
const muted = Color(0xFF686B63);
const accent = Color(0xFF963F34);
const rule = Color(0xFFDFDFD4);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    runApp(ReadingApp(store: await ShelfStore.forDevice()));
  } catch (_) {
    runApp(MaterialApp(home: Scaffold(body: SafeArea(child: Center(child: Padding(
      padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('无法读取本机阅读记录'), const SizedBox(height: 16),
        FilledButton(onPressed: main, child: const Text('重试')),
      ]),
    ))))));
  }
}

class ReadingApp extends StatelessWidget {
  const ReadingApp({super.key, required this.store, this.textScale});
  final ShelfStore store;
  final double? textScale;
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: '书架', debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true, scaffoldBackgroundColor: paper, fontFamily: 'ShelfSans',
      colorScheme: ColorScheme.fromSeed(seedColor: accent, surface: paper),
      textTheme: ThemeData.light().textTheme.apply(bodyColor: ink, displayColor: ink, fontFamily: 'ShelfSans'),
      textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(
        foregroundColor: accent, minimumSize: const Size(48, 48),
        padding: const EdgeInsets.symmetric(horizontal: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      )),
    ),
    builder: (context, child) => textScale == null ? child! : MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(textScale!)), child: child!,
    ),
    home: ShelfPage(store: store),
  );
}

class ShelfPage extends StatelessWidget {
  const ShelfPage({super.key, required this.store});
  final ShelfStore store;
  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(
    child: ListenableBuilder(listenable: store, builder: (context, _) => ListView(
      padding: const EdgeInsets.fromLTRB(24, 30, 24, 28),
      children: [
        const Text('书架', style: TextStyle(fontFamily: 'ShelfSerif', fontSize: 32, height: 1.3, fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        const Text('三本示例短篇', style: TextStyle(fontSize: 13, color: muted)),
        const SizedBox(height: 18),
        for (int i = 0; i < books.length; i++) ...[
          Padding(padding: const EdgeInsets.symmetric(vertical: 20), child: _bookRow(context, books[i], i)),
          if (i < books.length - 1) const Divider(height: 1, color: rule),
        ],
      ],
    )),
  ));

  Widget _bookRow(BuildContext context, Book book, int index) {
    Future<void> open() async {
      await Navigator.of(context).push<void>(MaterialPageRoute(builder: (_) => ReaderPage(book: book, store: store)));
    }
    final started = store.positions.containsKey(book.id);
    final largeText = MediaQuery.textScalerOf(context).scale(22) > 32;
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Semantics(label: '${book.title}封面', image: true, child: ExcludeSemantics(child: GestureDetector(
        onTap: open, child: SizedBox(
          width: largeText ? 64 : 92, height: largeText ? 92 : 132,
          child: FittedBox(child: BookCover(book: book, index: index)),
        ),
      ))),
      SizedBox(width: largeText ? 16 : 22),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 3),
        Text(book.title, style: const TextStyle(fontFamily: 'ShelfSerif', fontSize: 22, height: 1.4, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Text(book.excerpt, style: const TextStyle(fontSize: 14, height: 1.7, color: muted)),
        const SizedBox(height: 10),
        TextButton(key: Key('open-${book.id}'), onPressed: open,
          child: Wrap(crossAxisAlignment: WrapCrossAlignment.center, spacing: 8, children: [
            Text(started ? '继续阅读' : '打开阅读', style: const TextStyle(fontSize: 15)),
            const Icon(Icons.arrow_forward, size: 18),
          ])),
      ])),
    ]);
  }
}

class BookCover extends StatelessWidget {
  const BookCover({super.key, required this.book, required this.index});
  final Book book;
  final int index;
  @override
  Widget build(BuildContext context) => Container(
    width: 92, height: 132,
    decoration: BoxDecoration(color: book.color, borderRadius: BorderRadius.circular(2),
      boxShadow: [BoxShadow(color: ink.withValues(alpha: .13), blurRadius: 5, offset: const Offset(0, 3))]),
    child: Stack(children: [
      Positioned(left: 7, top: 0, bottom: 0, child: Container(width: 1, color: Colors.white24)),
      Positioned(left: 8, right: 0, top: 18, child: Text(book.title,
        textAlign: TextAlign.center, textScaler: TextScaler.noScaling,
        style: const TextStyle(fontFamily: 'ShelfSerif', fontSize: 15, color: Color(0xFFF4EBD7), letterSpacing: 1))),
      Positioned(left: 21, right: 14, top: 68, bottom: 20, child: CustomPaint(painter: _CoverLines(index))),
    ]),
  );
}

class _CoverLines extends CustomPainter {
  _CoverLines(this.index);
  final int index;
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = const Color(0xFFDCD9BD)..strokeWidth = .8..style = PaintingStyle.stroke;
    if (index == 0) {
      for (int i = 0; i < 3; i++) {
        final y = 10.0 + i * 7;
        canvas.drawPath(Path()..moveTo(0,y)..cubicTo(size.width*.4,y-8,size.width*.55,y+8,size.width*.77,y),p);
      }
      canvas.drawRect(Rect.fromLTWH(size.width*.78,0,size.width*.22,25),p);
    } else if (index == 1) {
      canvas.drawPath(Path()..moveTo(0,28)..lineTo(14,20)..quadraticBezierTo(25,0,33,14)..lineTo(50,25)..lineTo(size.width,27),p);
      canvas.drawPath(Path()..moveTo(13,34)..quadraticBezierTo(30,38,48,40),p);
    } else {
      canvas.drawRect(Rect.fromLTWH(18,0,27,39),p);
      canvas.drawLine(const Offset(31.5,0), const Offset(31.5,39),p);
      canvas.drawLine(const Offset(18,19),const Offset(45,19),p);
      canvas.drawLine(const Offset(8,40), const Offset(54,40),p);
    }
  }
  @override
  bool shouldRepaint(_CoverLines oldDelegate) => oldDelegate.index != index;
}

class ReaderPage extends StatefulWidget {
  const ReaderPage({super.key, required this.book, required this.store});
  final Book book;
  final ShelfStore store;
  @override
  State<ReaderPage> createState() => ReaderState();
}

class ReaderState extends State<ReaderPage> with WidgetsBindingObserver {
  final ScrollController scroll = ScrollController();
  late final List<GlobalKey> paragraphKeys;
  Timer? _timer;
  int paragraph = 0;
  String? saveError;
  bool _leaving = false;
  @override
  void initState() {
    super.initState();
    paragraphKeys = List.generate(widget.book.paragraphs.length, (_) => GlobalKey());
    WidgetsBinding.instance.addObserver(this);
    scroll.addListener(_onScroll);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _restore(widget.store.positions[widget.book.id] ?? const ReadingPosition(0, 0));
      _remember();
    });
  }

  double _offsetFor(int i) {
    final render = paragraphKeys[i].currentContext?.findRenderObject();
    if (render == null) return 0;
    return RenderAbstractViewport.of(render).getOffsetToReveal(render, 0).offset;
  }

  RenderParagraph? _textFor(int i) {
    final render = paragraphKeys[i].currentContext?.findRenderObject();
    return render is RenderPadding && render.child is RenderParagraph
      ? render.child as RenderParagraph : null;
  }

  ReadingPosition _capture() {
    if (!scroll.hasClients) return const ReadingPosition(0, 0);
    var index = 0;
    for (int i = 0; i < paragraphKeys.length; i++) {
      if (_offsetFor(i) <= scroll.offset + 1) index = i;
    }
    final inside = math.max(0.0, scroll.offset - _offsetFor(index));
    final text = _textFor(index);
    if (text == null || inside >= text.size.height) return ReadingPosition(index, inside);
    final position = text.getPositionForOffset(Offset(0, inside));
    final lineTop = text.getOffsetForCaret(position, Rect.zero).dy;
    final lineHeight = text.getFullHeightForCaret(position);
    return ReadingPosition(index, inside, character: position.offset,
      lineProgress: lineHeight > 0 ? ((inside - lineTop) / lineHeight).clamp(-1, 1) : 0);
  }

  void _restore(ReadingPosition position) {
    if (!scroll.hasClients) return;
    final index = position.paragraph.clamp(0, paragraphKeys.length - 1);
    var inside = position.inside;
    final text = _textFor(index);
    if (text != null && position.character != null) {
      final caret = TextPosition(offset: position.character!.clamp(0, text.text.toPlainText().length));
      // Reflow changes pixel offsets. Restore the line containing the same text.
      inside = text.getOffsetForCaret(caret, Rect.zero).dy
        + position.lineProgress * text.getFullHeightForCaret(caret);
    }
    final target = position.paragraph == 0 && position.inside == 0
      ? 0.0 : _offsetFor(index) + inside;
    scroll.jumpTo(target.clamp(0, scroll.position.maxScrollExtent));
  }

  void _onScroll() {
    final current = _capture();
    if (paragraph != current.paragraph) setState(() => paragraph = current.paragraph);
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 250), _remember);
  }

  Future<bool> _remember() async {
    _timer?.cancel();
    widget.store.positions[widget.book.id] = _capture();
    try {
      await widget.store.save();
      if (mounted && saveError != null) setState(() => saveError = null);
      return true;
    } catch (_) {
      if (mounted) setState(() => saveError = '阅读位置未保存');
      return false;
    }
  }

  Future<void> _leave() async {
    if (_leaving) return;
    setState(() => _leaving = true);
    final saved = await _remember();
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    Navigator.of(context).pop();
    if (!saved) {
      messenger.showSnackBar(const SnackBar(
        content: Text('阅读位置未保存，已返回书架'),
        duration: Duration(seconds: 8),
      ));
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) _remember();
  }

  Future<void> _fontSettings() async {
    // Keep one text anchor throughout a slider gesture, even across many reflows.
    final anchor = _capture();
    await showModalBottomSheet<void>(context: context, backgroundColor: paper, showDragHandle: true,
      builder: (context) => StatefulBuilder(builder: (context, updateSheet) => SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 24), child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Align(alignment: Alignment.centerLeft, child: Text('正文字号', style: TextStyle(fontSize: 18))),
          const SizedBox(height: 16),
          Row(children: [
            const Text('小'),
            Expanded(child: Slider(key: const Key('font-slider'), min: 16, max: 28, divisions: 6,
              value: widget.store.fontSize,
              semanticFormatterCallback: (value) => '${value.round()}号',
              onChanged: (value) {
                setState(() => widget.store.fontSize = value);
                updateSheet(() {});
                WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) _restore(anchor); });
              },
              onChangeEnd: (_) => _remember(),
            )),
            const Text('大'),
          ]),
          const SizedBox(height: 8),
          TextButton(key: const Key('font-done'), onPressed: () => Navigator.pop(context), child: const Text('完成')),
        ]),
      ))));
    if (mounted) await _remember();
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: _leaving,
    onPopInvokedWithResult: (didPop, result) { if (!didPop) _leave(); },
    child: Scaffold(body: SafeArea(child: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 5), child: Row(children: [
        TextButton(key: const Key('back-shelf'), onPressed: _leave,
          child: const Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.chevron_left, size: 25), Text('书架', style: TextStyle(fontSize: 15)),
          ])),
        const Spacer(),
        TextButton(key: const Key('font-settings'), onPressed: _fontSettings,
          child: Semantics(label: '调整字号', child: const Text('Aa', style: TextStyle(fontFamily: 'ShelfSerif', fontSize: 21)))),
      ])),
      Expanded(child: SingleChildScrollView(key: const Key('reader-scroll'), controller: scroll,
        padding: const EdgeInsets.fromLTRB(28, 25, 28, 32),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.book.title, style: const TextStyle(fontFamily: 'ShelfSerif', fontSize: 30, height: 1.4, fontWeight: FontWeight.w600)),
          const SizedBox(height: 20),
          Text(widget.book.chapter, style: const TextStyle(fontFamily: 'ShelfSerif', fontSize: 21, height: 1.5, fontWeight: FontWeight.w500)),
          const SizedBox(height: 20),
          for (int i = 0; i < widget.book.paragraphs.length; i++)
            Padding(key: paragraphKeys[i], padding: const EdgeInsets.only(bottom: 23), child: Text(
              '　　${widget.book.paragraphs[i]}', key: Key('paragraph-$i'),
              style: TextStyle(fontFamily: 'ShelfSerif', fontSize: widget.store.fontSize, height: 1.9, color: ink),
            )),
        ]),
      )),
      Padding(padding: const EdgeInsets.fromLTRB(24, 10, 24, 14), child: Text(
        saveError ?? '第 ${paragraph + 1} 段 · 共 ${widget.book.paragraphs.length} 段',
        style: TextStyle(fontSize: 12, color: saveError == null ? muted : accent),
      )),
    ]))),
  );
}
